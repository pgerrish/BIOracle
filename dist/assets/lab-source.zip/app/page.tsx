import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Dna, Activity, TrendingUp, Citrus as Virus, DollarSign, LineChart } from "lucide-react"

export default function HomePage() {
  const researchAreas = [
    {
      title: "DNA/RNA Evolution",
      description: "Historical reconstruction with phylogenetics and molecular evolution",
      icon: Dna,
      href: "/research/dna-rna",
    },
    {
      title: "Somatic Evolution & Cancer",
      description: "Understanding cancer through the lens of evolutionary processes",
      icon: Activity,
      href: "/research/cancer",
    },
    {
      title: "Microbes",
      description: "Evolutionary dynamics of microbial populations and communities",
      icon: TrendingUp,
      href: "/research/microbes",
    },
    {
      title: "Immunity",
      description: "Evolutionary perspectives on immune system function and host defense",
      icon: Virus,
      href: "/research/immunity",
    },
    {
      title: "Financial Markets Evolution",
      description: "Evolutionary dynamics in economic systems and market behavior",
      icon: DollarSign,
      href: "/research/markets",
    },
    {
      title: "Evolutionary Forecasting",
      description: "Leveraging evolutionary principles to forecast future states of large noisy systems",
      icon: LineChart,
      href: "/research/forecasting",
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8 lg:py-32">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-6xl">Evolutionary Processes Lab</h1>
            <p className="mt-6 text-pretty text-lg leading-relaxed text-muted-foreground">
              We bring together the limitless creative power of evolution and the exciting new universe of artificial
              intelligence to explore second- and third-order evolutionary processes. First-order evolutionary processes
              have been famously likened to a "blind watchmaker". Higher-order evolutionary processes, however, become
              increasingly less blind. We study application of such processes across diverse contexts -— from molecular
              biology to financial markets. Our lab bridges private and public sectors, embracing apprenticeship and
              entrepreneurial spirit while rejecting for-profit education.
            </p>
            <div className="mt-10 flex items-center justify-center gap-4">
              <Button asChild size="lg">
                <Link href="/collaborations">
                  Meet Our Team <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/contractor">Partner With Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Research Areas */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-16 text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Research Areas</h2>
            <p className="mt-4 text-lg text-muted-foreground">Exploring evolution across six interconnected domains</p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {researchAreas.map((area) => {
              const Icon = area.icon
              return (
                <Link key={area.href} href={area.href}>
                  <Card className="h-full transition-colors hover:border-primary">
                    <CardHeader>
                      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>{area.title}</CardTitle>
                      <CardDescription>{area.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center text-sm font-medium text-primary">
                        Learn more <ArrowRight className="ml-2 h-4 w-4" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="border-t border-border py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Our Philosophy</h2>
            <div className="mt-8 space-y-6 text-lg leading-relaxed text-muted-foreground">
              <p>
                We straddle the private and public sectors, rejecting notions of for-profit education while embracing
                the apprenticeship model and entrepreneurial spirit.
              </p>
              <p>
                Our lab operates at the intersection of rigorous scientific inquiry and practical application,
                partnering with universities, businesses, and government agencies to advance evolutionary theory and its
                applications.
              </p>
              <p>
                Through collaborative research and mentorship, we train the next generation of evolutionary theorists
                while contributing to real-world solutions across diverse fields.
              </p>
            </div>
            <div className="mt-10">
              <Button asChild size="lg">
                <Link href="/contractor">
                  Explore Partnership Opportunities <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} Evolutionary Processes Lab. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
