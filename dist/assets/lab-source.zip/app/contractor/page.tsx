"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Building2, GraduationCap, Landmark, Heart, CheckCircle2 } from "lucide-react"

export default function ContractorPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    organization: "",
    partnershipType: "",
    message: "",
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would send data to a server
    console.log("Form submitted:", formData)
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const partnershipTypes = [
    {
      title: "University Partnerships",
      description: "Collaborative research agreements, joint grant applications, and academic exchange programs",
      icon: GraduationCap,
    },
    {
      title: "Business Contracts",
      description: "Applied research projects, consulting services, and technology transfer opportunities",
      icon: Building2,
    },
    {
      title: "Government Funding",
      description: "Federal and state research grants, public health initiatives, and policy advisory roles",
      icon: Landmark,
    },
    {
      title: "Donations",
      description: "Support our research through tax-deductible donations and philanthropic partnerships",
      icon: Heart,
    },
  ]

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Partner With Us</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Collaborate with our lab to advance evolutionary research and its applications
          </p>
        </div>

        {/* Partnership Types */}
        <section className="mb-20">
          <h2 className="mb-8 text-center text-3xl font-bold">Partnership Opportunities</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {partnershipTypes.map((type) => {
              const Icon = type.icon
              return (
                <Card key={type.title} className="text-center">
                  <CardHeader>
                    <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{type.title}</CardTitle>
                    <CardDescription className="text-sm">{type.description}</CardDescription>
                  </CardHeader>
                </Card>
              )
            })}
          </div>
        </section>

        {/* Our Approach */}
        <section className="mb-20">
          <div className="mx-auto max-w-3xl">
            <h2 className="mb-8 text-center text-3xl font-bold">Our Unique Approach</h2>
            <div className="space-y-6 text-lg leading-relaxed text-muted-foreground">
              <p>
                The Evolutionary Processes Lab operates at the intersection of rigorous academic research and practical
                real-world applications. We reject the notion of for-profit education while embracing the
                entrepreneurial spirit and apprenticeship model.
              </p>
              <p>
                Our lab straddles both private and public sectors, enabling us to work flexibly with universities,
                businesses, and government agencies. This unique positioning allows us to pursue fundamental research
                questions while delivering tangible value to our partners.
              </p>
              <p>
                Whether you're seeking cutting-edge evolutionary analysis for your organization, looking to fund
                groundbreaking research, or interested in collaborative projects, we welcome the opportunity to explore
                how we can work together.
              </p>
            </div>
          </div>
        </section>

        {/* What We Offer */}
        <section className="mb-20">
          <h2 className="mb-8 text-center text-3xl font-bold">What We Offer</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Research Expertise</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Access to world-class researchers across five domains: molecular evolution, cancer biology,
                  epidemiology, disease evolution, and financial markets.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Computational Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Custom software development, data analysis pipelines, and evolutionary modeling tailored to your
                  specific needs.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Training Programs</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Workshops, seminars, and apprenticeship opportunities to build evolutionary thinking capacity in your
                  organization.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Consulting Services</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Strategic advice on applying evolutionary principles to complex problems in healthcare, finance, and
                  technology.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Collaborative Research</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Joint research projects, co-authored publications, and shared intellectual property development.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Grant Support</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Assistance with grant writing, project design, and securing funding from federal and private sources.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Form */}
        <section className="mx-auto max-w-2xl">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Get in Touch</CardTitle>
              <CardDescription>
                Fill out the form below and we'll get back to you within 48 hours to discuss partnership opportunities.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Your full name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="your.email@example.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="organization">Organization</Label>
                  <Input
                    id="organization"
                    name="organization"
                    value={formData.organization}
                    onChange={handleChange}
                    placeholder="Your university, company, or agency"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="partnershipType">Partnership Type *</Label>
                  <Input
                    id="partnershipType"
                    name="partnershipType"
                    required
                    value={formData.partnershipType}
                    onChange={handleChange}
                    placeholder="e.g., Research collaboration, Consulting, Donation"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Message *</Label>
                  <Textarea
                    id="message"
                    name="message"
                    required
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell us about your project or partnership interest..."
                    rows={6}
                  />
                </div>

                <Button type="submit" className="w-full" size="lg" disabled={submitted}>
                  {submitted ? (
                    <>
                      <CheckCircle2 className="mr-2 h-5 w-5" />
                      Message Sent!
                    </>
                  ) : (
                    "Submit Inquiry"
                  )}
                </Button>

                {submitted && (
                  <p className="text-center text-sm text-muted-foreground">
                    Thank you for your interest! We'll be in touch soon.
                  </p>
                )}
              </form>
            </CardContent>
          </Card>
        </section>

        {/* Additional Contact Info */}
        <section className="mt-12 text-center">
          <p className="text-muted-foreground">
            For general inquiries, email us at{" "}
            <a href="mailto:info@teplab.org" className="text-primary hover:underline">
              info@teplab.org
            </a>
          </p>
        </section>
      </div>
    </div>
  )
}
