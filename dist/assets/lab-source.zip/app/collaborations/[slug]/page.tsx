import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Mail, Globe, GraduationCap, BookOpen } from "lucide-react"

// This would typically come from a database or CMS
const peopleData: Record<string, any> = {
  "sarah-chen": {
    name: "Dr. Sarah Chen",
    role: "Principal Investigator",
    image: "/professional-woman-scientist.png",
    email: "sarah.chen@teplab.org",
    website: "https://sarahchen.research.org",
    expertise: ["Phylogenetics", "Molecular Evolution", "Computational Biology"],
    bio: "Dr. Chen leads the Evolutionary Processes Lab with a focus on phylogenetic methods and molecular evolution. Her work has pioneered new approaches to understanding deep evolutionary relationships through genomic data. With over 15 years of experience, she has published extensively on RNA evolution and computational phylogenetics.",
    education: [
      "PhD in Evolutionary Biology, Stanford University",
      "MS in Computational Biology, MIT",
      "BS in Biology, UC Berkeley",
    ],
    researchInterests: [
      "Phylogenetic inference methods",
      "RNA structure evolution",
      "Ancient DNA analysis",
      "Molecular clock modeling",
    ],
    selectedPublications: [
      "Chen, S. et al. (2023). Novel approaches to deep-time phylogenetic reconstruction. Nature Methods.",
      "Chen, S. & Rodriguez, M. (2022). RNA structure constraints in viral evolution. Molecular Biology and Evolution.",
      "Chen, S. et al. (2021). Computational methods for ancient DNA analysis. Genome Research.",
    ],
  },
  "michael-rodriguez": {
    name: "Dr. Michael Rodriguez",
    role: "Senior Research Scientist",
    image: "/professional-scientist.png",
    email: "michael.rodriguez@teplab.org",
    website: "https://mrodriguez.research.org",
    expertise: ["Cancer Evolution", "Computational Biology", "Tumor Dynamics"],
    bio: "Dr. Rodriguez specializes in applying evolutionary theory to understand cancer progression and treatment resistance. His interdisciplinary approach combines genomics, mathematical modeling, and clinical data to develop evolution-informed cancer therapies. He has been instrumental in establishing collaborations with major cancer research centers.",
    education: [
      "PhD in Cancer Biology, Johns Hopkins University",
      "MS in Applied Mathematics, Caltech",
      "BS in Biochemistry, UCLA",
    ],
    researchInterests: [
      "Clonal evolution in tumors",
      "Adaptive therapy strategies",
      "Single-cell genomics",
      "Treatment resistance mechanisms",
    ],
    selectedPublications: [
      "Rodriguez, M. et al. (2023). Evolutionary dynamics of treatment resistance in cancer. Cell.",
      "Rodriguez, M. & Chen, S. (2022). Phylogenetic approaches to tumor evolution. Cancer Research.",
      "Rodriguez, M. et al. (2021). Adaptive therapy design using evolutionary game theory. Nature Medicine.",
    ],
  },
  "aisha-patel": {
    name: "Dr. Aisha Patel",
    role: "Associate Researcher",
    image: "/professional-woman-researcher.png",
    email: "aisha.patel@teplab.org",
    website: "https://apatel.research.org",
    expertise: ["Epidemiology", "Public Health", "Disease Modeling"],
    bio: "Dr. Patel brings expertise in evolutionary epidemiology and public health to the lab. Her research focuses on understanding how pathogens evolve in response to interventions and how evolutionary thinking can improve disease control strategies. She maintains active collaborations with public health agencies worldwide.",
    education: [
      "PhD in Epidemiology, Harvard University",
      "MPH in Global Health, Columbia University",
      "BS in Biology, University of Michigan",
    ],
    researchInterests: [
      "Pathogen evolution and transmission",
      "Vaccine escape dynamics",
      "Phylodynamic inference",
      "Public health intervention design",
    ],
    selectedPublications: [
      "Patel, A. et al. (2023). Evolution-informed strategies for pandemic preparedness. Science.",
      "Patel, A. & Sharma, P. (2022). Phylodynamics of emerging infectious diseases. PLOS Pathogens.",
      "Patel, A. et al. (2021). Optimizing intervention timing using evolutionary models. Epidemiology.",
    ],
  },
  "james-thompson": {
    name: "Dr. James Thompson",
    role: "Research Fellow",
    image: "/professional-man-economist.jpg",
    email: "james.thompson@teplab.org",
    website: "https://jthompson.research.org",
    expertise: ["Financial Markets", "Quantitative Analysis", "Evolutionary Economics"],
    bio: "Dr. Thompson applies evolutionary theory to financial markets, studying how trading strategies and market structures evolve over time. His unique background in both evolutionary biology and quantitative finance enables novel insights into market dynamics. He works closely with financial institutions to develop evolution-aware trading systems.",
    education: [
      "PhD in Quantitative Finance, University of Chicago",
      "MS in Evolutionary Biology, Princeton University",
      "BS in Mathematics, Cambridge University",
    ],
    researchInterests: [
      "Algorithmic trading evolution",
      "Market ecology and dynamics",
      "Cryptocurrency evolution",
      "Behavioral finance from an evolutionary perspective",
    ],
    selectedPublications: [
      "Thompson, J. et al. (2023). Evolutionary dynamics in high-frequency trading. Journal of Finance.",
      "Thompson, J. & Kim, D. (2022). Cryptocurrency markets as evolutionary systems. Nature Finance.",
      "Thompson, J. et al. (2021). Agent-based models of market evolution. Quantitative Finance.",
    ],
  },
  "emily-zhang": {
    name: "Emily Zhang",
    role: "PhD Candidate",
    image: "/young-woman-graduate-student.jpg",
    email: "emily.zhang@teplab.org",
    expertise: ["Viral Evolution", "Bioinformatics", "Genomic Analysis"],
    bio: "Emily is a PhD candidate studying viral evolution with a focus on RNA viruses. Her dissertation research examines how viral populations adapt to host immune responses and antiviral treatments. She has developed novel bioinformatics tools for analyzing viral sequence data from clinical samples.",
    education: ["MS in Bioinformatics, UC San Diego", "BS in Computer Science, Cornell University"],
    researchInterests: [
      "Viral adaptation mechanisms",
      "Immune escape evolution",
      "Bioinformatics tool development",
      "Clinical viral genomics",
    ],
    selectedPublications: [
      "Zhang, E. & Chen, S. (2023). Rapid adaptation in RNA virus populations. Virus Evolution.",
      "Zhang, E. et al. (2022). Novel tools for viral phylodynamic analysis. Bioinformatics.",
    ],
  },
  "marcus-johnson": {
    name: "Marcus Johnson",
    role: "PhD Candidate",
    image: "/young-man-graduate-student.jpg",
    email: "marcus.johnson@teplab.org",
    expertise: ["Tumor Heterogeneity", "Single-Cell Analysis", "Cancer Genomics"],
    bio: "Marcus is investigating tumor heterogeneity and clonal evolution using single-cell sequencing technologies. His work aims to understand how different cancer cell populations compete and cooperate within tumors, with implications for predicting treatment outcomes.",
    education: ["MS in Cancer Biology, MD Anderson Cancer Center", "BS in Molecular Biology, Yale University"],
    researchInterests: [
      "Single-cell genomics",
      "Tumor microenvironment evolution",
      "Clonal competition dynamics",
      "Predictive modeling of treatment response",
    ],
    selectedPublications: [
      "Johnson, M. & Rodriguez, M. (2023). Spatial patterns of clonal evolution in tumors. Cancer Cell.",
      "Johnson, M. et al. (2022). Single-cell analysis reveals tumor ecosystem dynamics. Nature Communications.",
    ],
  },
  "priya-sharma": {
    name: "Priya Sharma",
    role: "PhD Candidate",
    image: "/young-woman-phd-student.jpg",
    email: "priya.sharma@teplab.org",
    expertise: ["Disease Modeling", "Statistical Methods", "Epidemiological Analysis"],
    bio: "Priya develops statistical methods for analyzing disease evolution and transmission. Her research combines mathematical modeling with genomic epidemiology to track pathogen spread and predict outbreak dynamics. She is particularly interested in antimicrobial resistance evolution.",
    education: ["MS in Biostatistics, University of Washington", "BS in Statistics, University of Toronto"],
    researchInterests: [
      "Statistical phylodynamics",
      "Antimicrobial resistance modeling",
      "Outbreak prediction",
      "Bayesian inference methods",
    ],
    selectedPublications: [
      "Sharma, P. & Patel, A. (2023). Bayesian methods for transmission network inference. Epidemics.",
      "Sharma, P. et al. (2022). Modeling antimicrobial resistance evolution. PLOS Computational Biology.",
    ],
  },
  "david-kim": {
    name: "David Kim",
    role: "Master's Student",
    image: "/young-man-masters-student.jpg",
    email: "david.kim@teplab.org",
    expertise: ["Algorithmic Trading", "Machine Learning", "Market Analysis"],
    bio: "David is a master's student working on evolutionary dynamics in algorithmic trading systems. His thesis explores how machine learning algorithms compete and adapt in financial markets, drawing parallels with biological evolution.",
    education: ["BS in Computer Science, Carnegie Mellon University"],
    researchInterests: [
      "Machine learning in finance",
      "Evolutionary algorithms",
      "High-frequency trading dynamics",
      "Market microstructure",
    ],
    selectedPublications: [
      "Kim, D. & Thompson, J. (2023). Evolution of trading algorithms in competitive markets. arXiv preprint.",
    ],
  },
  "sofia-martinez": {
    name: "Sofia Martinez",
    role: "Master's Student",
    image: "/young-woman-masters-student.jpg",
    email: "sofia.martinez@teplab.org",
    expertise: ["RNA Structure", "Comparative Genomics", "Molecular Evolution"],
    bio: "Sofia is studying RNA structure evolution across diverse organisms. Her master's research focuses on understanding how functional constraints shape RNA secondary structure evolution, with applications to understanding viral adaptation.",
    education: ["BS in Molecular Biology, University of Texas at Austin"],
    researchInterests: [
      "RNA structure prediction",
      "Comparative genomics",
      "Functional constraint analysis",
      "Viral RNA evolution",
    ],
    selectedPublications: [
      "Martinez, S. & Chen, S. (2023). Constraints on RNA structure evolution in viruses. RNA Biology.",
    ],
  },
  "alex-chen": {
    name: "Alex Chen",
    role: "Research Assistant",
    image: "/young-person-research-assistant.jpg",
    email: "alex.chen@teplab.org",
    expertise: ["Data Analysis", "Visualization", "Computational Tools"],
    bio: "Alex supports multiple research projects in the lab through data analysis and visualization. They develop interactive tools for exploring evolutionary data and help maintain the lab's computational infrastructure.",
    education: ["BS in Data Science, UC Berkeley"],
    researchInterests: [
      "Data visualization",
      "Scientific computing",
      "Bioinformatics pipelines",
      "Interactive analysis tools",
    ],
    selectedPublications: [],
  },
}

export default function PersonPage({ params }: { params: { slug: string } }) {
  const person = peopleData[params.slug]

  if (!person) {
    notFound()
  }

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <Button asChild variant="ghost" className="mb-8">
          <Link href="/collaborations">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Collaborations
          </Link>
        </Button>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="mb-8">
              <h1 className="text-4xl font-bold tracking-tight">{person.name}</h1>
              <p className="mt-2 text-xl text-muted-foreground">{person.role}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {person.expertise.map((skill: string) => (
                  <Badge key={skill} variant="secondary">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-8">
              <section>
                <h2 className="mb-4 text-2xl font-bold">Biography</h2>
                <p className="text-muted-foreground leading-relaxed">{person.bio}</p>
              </section>

              <section>
                <h2 className="mb-4 text-2xl font-bold">Education</h2>
                <ul className="space-y-2">
                  {person.education.map((degree: string, index: number) => (
                    <li key={index} className="flex items-start gap-3">
                      <GraduationCap className="mt-1 h-5 w-5 flex-shrink-0 text-primary" />
                      <span className="text-muted-foreground">{degree}</span>
                    </li>
                  ))}
                </ul>
              </section>

              <section>
                <h2 className="mb-4 text-2xl font-bold">Research Interests</h2>
                <ul className="grid gap-3 sm:grid-cols-2">
                  {person.researchInterests.map((interest: string, index: number) => (
                    <li key={index} className="flex items-start gap-3">
                      <div className="mt-1 h-2 w-2 flex-shrink-0 rounded-full bg-primary" />
                      <span className="text-muted-foreground">{interest}</span>
                    </li>
                  ))}
                </ul>
              </section>

              {person.selectedPublications && person.selectedPublications.length > 0 && (
                <section>
                  <h2 className="mb-4 text-2xl font-bold">Selected Publications</h2>
                  <ul className="space-y-4">
                    {person.selectedPublications.map((pub: string, index: number) => (
                      <li key={index} className="flex items-start gap-3">
                        <BookOpen className="mt-1 h-5 w-5 flex-shrink-0 text-primary" />
                        <span className="text-sm text-muted-foreground">{pub}</span>
                      </li>
                    ))}
                  </ul>
                </section>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <div className="aspect-square overflow-hidden rounded-t-lg">
                <img
                  src={person.image || "/placeholder.svg"}
                  alt={person.name}
                  className="h-full w-full object-cover"
                />
              </div>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {person.email && (
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-muted-foreground" />
                    <a href={`mailto:${person.email}`} className="text-sm text-primary hover:underline">
                      {person.email}
                    </a>
                  </div>
                )}
                {person.website && (
                  <div className="flex items-center gap-3">
                    <Globe className="h-5 w-5 text-muted-foreground" />
                    <a
                      href={person.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary hover:underline"
                    >
                      Personal Website
                    </a>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Collaborate</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-sm text-muted-foreground">
                  Interested in collaborating or learning more about this research?
                </p>
                <Button asChild className="w-full">
                  <Link href="/contractor">Get in Touch</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
