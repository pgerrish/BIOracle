import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold">Person Not Found</h1>
        <p className="mt-4 text-muted-foreground">The person you're looking for doesn't exist in our directory.</p>
        <Button asChild className="mt-8">
          <Link href="/collaborations">Back to Collaborations</Link>
        </Button>
      </div>
    </div>
  )
}
