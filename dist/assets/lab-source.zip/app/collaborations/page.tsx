import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function CollaborationsPage() {
  const faculty = [
    {
      name: "Dr. Philip Gerrish",
      role: "Principal Investigator",
      expertise: ["Evolutionary Theory", "Probability Theory"],
      image: "/teaching3.png",
      slug: "phil-gerrish",
    },
    {
      name: "Dr. Erika Rodriguez",
      role: "Professor",
      expertise: ["Neuroscience", "Complexity and Fractals"],
      image: "/erika1c.jpg",
      slug: "erika-rodriguez",
    },
    {
      name: "Dr. Benjamin Itza",
      role: "Professor",
      expertise: ["Topology", "Algebra"],
      image: "/ben1.jpeg",
      slug: "ben-itza",
    },
    {
      name: "Dr. Pablo Padilla",
      role: "Professor",
      expertise: ["Physics", "Mathematics", "Music Theory"],
      image: "/pablo1.jpg",
      slug: "pablo-padilla",
    },
    {
      name: "Dr. Paul Sniegowski",
      role: "Professor",
      expertise: ["Evolutionary Biology", "Population Genetics"],
      image: "/paul1.jpg",
      slug: "paul-sniegowski",
    },
    {
      name: "Dr. Lindi Wahl",
      role: "Professor",
      expertise: ["Applied Mathematics", "Evolutionary Genetics"],
      image: "/lindi2.png",
      slug: "lindi-wahl",
    },
    {
      name: "Dr. Valeria Souza",
      role: "Professor",
      expertise: ["Microbial Ecology", "Evolutionary Biology"],
      image: "/valeria1.jpg",
      slug: "valeria-souza",
    },
    {
      name: "Dr. Gabriela Gomes",
      role: "Professor",
      expertise: ["Applied Mathematics", "Epidimiology"],
      image: "/gabriela1.jpg",
      slug: "gabriela-gomes",
    },
  ]

  const students = [
    {
      name: "Emily Zhang",
      role: "PhD Candidate",
      expertise: ["Viral Evolution", "Bioinformatics"],
      image: "/young-woman-graduate-student.jpg",
      slug: "emily-zhang",
    },
    {
      name: "Marcus Johnson",
      role: "PhD Candidate",
      expertise: ["Tumor Heterogeneity", "Single-Cell Analysis"],
      image: "/young-man-graduate-student.jpg",
      slug: "marcus-johnson",
    },
    {
      name: "Priya Sharma",
      role: "PhD Candidate",
      expertise: ["Disease Modeling", "Statistical Methods"],
      image: "/young-woman-phd-student.jpg",
      slug: "priya-sharma",
    },
    {
      name: "David Kim",
      role: "Master's Student",
      expertise: ["Algorithmic Trading", "Machine Learning"],
      image: "/young-man-masters-student.jpg",
      slug: "david-kim",
    },
    {
      name: "Sofia Martinez",
      role: "Master's Student",
      expertise: ["RNA Structure", "Comparative Genomics"],
      image: "/young-woman-masters-student.jpg",
      slug: "sofia-martinez",
    },
    {
      name: "Alex Chen",
      role: "Research Assistant",
      expertise: ["Data Analysis", "Visualization"],
      image: "/young-person-research-assistant.jpg",
      slug: "alex-chen",
    },
  ]

  const alumni = [
    {
      name: "Emily Zhang",
      role: "PhD Candidate",
      expertise: ["Viral Evolution", "Bioinformatics"],
      image: "/young-woman-graduate-student.jpg",
      slug: "emily-zhang",
    },
    {
      name: "Marcus Johnson",
      role: "PhD Candidate",
      expertise: ["Tumor Heterogeneity", "Single-Cell Analysis"],
      image: "/young-man-graduate-student.jpg",
      slug: "marcus-johnson",
    },
    {
      name: "Priya Sharma",
      role: "PhD Candidate",
      expertise: ["Disease Modeling", "Statistical Methods"],
      image: "/young-woman-phd-student.jpg",
      slug: "priya-sharma",
    },
    {
      name: "David Kim",
      role: "Master's Student",
      expertise: ["Algorithmic Trading", "Machine Learning"],
      image: "/young-man-masters-student.jpg",
      slug: "david-kim",
    },
    {
      name: "Sofia Martinez",
      role: "Master's Student",
      expertise: ["RNA Structure", "Comparative Genomics"],
      image: "/young-woman-masters-student.jpg",
      slug: "sofia-martinez",
    },
    {
      name: "Alex Chen",
      role: "Research Assistant",
      expertise: ["Data Analysis", "Visualization"],
      image: "/young-person-research-assistant.jpg",
      slug: "alex-chen",
    },
  ]

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Lab Members</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Meet the faculty and students driving evolutionary research forward
          </p>
        </div>

        {/* Faculty Section */}
        <section className="mb-20">
          <h2 className="mb-8 text-3xl font-bold">Faculty & Research Scientists</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {faculty.map((person) => (
              <Link key={person.slug} href={`/collaborations/${person.slug}`}>
                <Card className="group h-full overflow-hidden transition-all hover:border-primary">
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={person.image || "/placeholder.svg"}
                      alt={person.name}
                      className="h-full w-full object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold">{person.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{person.role}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {person.expertise.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Students Section */}
        <section>
          <h2 className="mb-8 text-3xl font-bold">Graduate Students & Research Assistants</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {students.map((person) => (
              <Link key={person.slug} href={`/collaborations/${person.slug}`}>
                <Card className="group h-full overflow-hidden transition-all hover:border-primary">
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={person.image || "/placeholder.svg"}
                      alt={person.name}
                      className="h-full w-full object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold">{person.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{person.role}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {person.expertise.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Alumni Section */}
        <section>
          <h2 className="mt-12 mb-8 text-3xl font-bold">Alumni</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {alumni.map((person) => (
              <Link key={person.slug} href={`/collaborations/${person.slug}`}>
                <Card className="group h-full overflow-hidden transition-all hover:border-primary">
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={person.image || "/placeholder.svg"}
                      alt={person.name}
                      className="h-full w-full object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold">{person.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{person.role}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {person.expertise.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Join Section */}
        <section className="mt-20 rounded-lg border border-border bg-card p-8 text-center">
          <h2 className="text-2xl font-bold">Join Our Lab</h2>
          <p className="mt-4 text-muted-foreground">
            We're always looking for passionate researchers interested in evolutionary processes. Whether you're a
            prospective student, postdoc, or collaborator, we'd love to hear from you.
          </p>
          <div className="mt-6">
            <Link
              href="/contractor"
              className="inline-flex items-center justify-center rounded-md bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Get in Touch
            </Link>
          </div>
        </section>
      </div>
    </div>
  )
}
