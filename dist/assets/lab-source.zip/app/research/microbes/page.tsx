import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, BookOpen, FlaskConical, Users } from "lucide-react"

export default function MicrobesPage() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <Button asChild variant="ghost" className="mb-8">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
        </Button>

        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Microbes</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Evolutionary dynamics of microbial populations and communities
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-2xl font-bold">Research Overview</h2>
              <p className="text-muted-foreground leading-relaxed">
                Microbial evolution operates at extraordinary speeds, making microbes ideal systems for studying
                evolutionary processes in real-time. Our research examines how bacteria, archaea, viruses, and fungi
                evolve in response to environmental pressures, competition, and cooperation within complex communities.
              </p>

              <h3 className="mt-8 text-xl font-bold">Key Research Areas</h3>
              <ul className="mt-4 space-y-3 text-muted-foreground">
                <li>
                  <strong className="text-foreground">Experimental Evolution:</strong> Using laboratory evolution
                  experiments to observe adaptation, mutation accumulation, and evolutionary innovation in real-time
                </li>
                <li>
                  <strong className="text-foreground">Microbial Community Dynamics:</strong> Modeling ecological and
                  evolutionary interactions within microbiomes and their impact on host health
                </li>
                <li>
                  <strong className="text-foreground">Horizontal Gene Transfer:</strong> Investigating how genetic
                  exchange between microbes accelerates adaptation and spreads traits like antibiotic resistance
                </li>
                <li>
                  <strong className="text-foreground">Metabolic Evolution:</strong> Understanding how microbial
                  metabolic networks evolve to exploit new resources and environmental niches
                </li>
                <li>
                  <strong className="text-foreground">Viral-Host Coevolution:</strong> Studying the evolutionary arms
                  race between bacteriophages and their bacterial hosts
                </li>
              </ul>

              <h3 className="mt-8 text-xl font-bold">Methodological Approaches</h3>
              <p className="text-muted-foreground leading-relaxed">
                We combine experimental evolution with high-throughput genomic sequencing, metagenomics, and
                computational modeling. Our work integrates population genetics theory with systems biology to predict
                evolutionary trajectories and understand the genetic basis of adaptation.
              </p>

              <h3 className="mt-8 text-xl font-bold">Current Projects</h3>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Antibiotic Resistance Evolution</CardTitle>
                    <CardDescription>
                      Tracking the emergence and spread of resistance mechanisms in bacterial populations under
                      different treatment regimens
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Microbiome Assembly Rules</CardTitle>
                    <CardDescription>
                      Determining how evolutionary and ecological processes shape the composition and function of
                      microbial communities
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Synthetic Microbial Consortia</CardTitle>
                    <CardDescription>
                      Engineering stable microbial communities for biotechnology applications using evolutionary
                      principles
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Publications</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Explore our research on microbial evolution, community dynamics, and experimental evolution.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Publications
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <FlaskConical className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Laboratory Resources</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Access our experimental protocols, strain collections, and genomic datasets.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  Browse Resources
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Collaborators</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Meet the researchers working on microbial evolution projects.
                </p>
                <Button asChild className="mt-4 w-full bg-transparent" variant="outline">
                  <Link href="/collaborations">View Team</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
