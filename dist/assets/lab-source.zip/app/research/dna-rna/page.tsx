import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, BookOpen, FlaskConical, Users } from "lucide-react"

export default function DNARNAPage() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <Button asChild variant="ghost" className="mb-8">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
        </Button>

        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">DNA/RNA Evolution & Phylogenetics</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Historical reconstruction and molecular evolution through computational phylogenetics
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-2xl font-bold">Research Overview</h2>
              <p className="text-muted-foreground leading-relaxed">
                Our DNA/RNA evolution research focuses on understanding the historical processes that have shaped
                genetic diversity across all domains of life. Using advanced phylogenetic methods, we reconstruct
                evolutionary relationships and infer the mechanisms driving molecular change.
              </p>

              <h3 className="mt-8 text-xl font-bold">Key Research Areas</h3>
              <ul className="mt-4 space-y-3 text-muted-foreground">
                <li>
                  <strong className="text-foreground">Phylogenetic Inference:</strong> Developing and applying maximum
                  likelihood and Bayesian methods to reconstruct evolutionary trees from molecular sequence data
                </li>
                <li>
                  <strong className="text-foreground">Molecular Clock Analysis:</strong> Estimating divergence times and
                  rates of evolution across different lineages and genomic regions
                </li>
                <li>
                  <strong className="text-foreground">RNA Structure Evolution:</strong> Investigating how RNA secondary
                  and tertiary structures evolve under functional constraints
                </li>
                <li>
                  <strong className="text-foreground">Codon Usage Bias:</strong> Analyzing selection pressures on
                  synonymous codon usage and their implications for gene expression
                </li>
                <li>
                  <strong className="text-foreground">Ancient DNA:</strong> Reconstructing evolutionary histories from
                  degraded genetic material in paleontological and archaeological samples
                </li>
              </ul>

              <h3 className="mt-8 text-xl font-bold">Methodological Approaches</h3>
              <p className="text-muted-foreground leading-relaxed">
                We employ cutting-edge computational methods including probabilistic models of sequence evolution,
                coalescent theory, and machine learning approaches to extract evolutionary signals from genomic data.
                Our work combines theoretical development with practical applications to biological questions.
              </p>

              <h3 className="mt-8 text-xl font-bold">Current Projects</h3>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Viral RNA Evolution</CardTitle>
                    <CardDescription>
                      Tracking rapid evolutionary changes in RNA viruses to predict emergence of new variants
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Deep Time Phylogenomics</CardTitle>
                    <CardDescription>
                      Resolving ancient evolutionary relationships using whole-genome data and novel substitution models
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Functional Constraint Mapping</CardTitle>
                    <CardDescription>
                      Identifying regions of genomes under purifying selection through comparative genomics
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Publications</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Explore our latest research papers and preprints on phylogenetic methods and molecular evolution.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Publications
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <FlaskConical className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Tools & Software</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Access our open-source phylogenetic analysis tools and computational pipelines.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  Browse Tools
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Collaborators</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Meet the researchers working on DNA/RNA evolution projects.
                </p>
                <Button asChild className="mt-4 w-full bg-transparent" variant="outline">
                  <Link href="/collaborations">View Team</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
