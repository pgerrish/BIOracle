import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, BookOpen, FlaskConical, Users } from "lucide-react"

export default function ImmunityPage() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <Button asChild variant="ghost" className="mb-8">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
        </Button>

        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Immunity</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Evolutionary perspectives on immune system function and host defense
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-2xl font-bold">Research Overview</h2>
              <p className="text-muted-foreground leading-relaxed">
                The immune system is a product of millions of years of coevolution with pathogens. Our research examines
                how evolutionary pressures have shaped immune function, diversity, and dysfunction. We study both the
                evolution of immunity across species and the rapid evolution occurring within individual immune
                responses.
              </p>

              <h3 className="mt-8 text-xl font-bold">Key Research Areas</h3>
              <ul className="mt-4 space-y-3 text-muted-foreground">
                <li>
                  <strong className="text-foreground">Adaptive Immune Diversity:</strong> Understanding how somatic
                  evolution generates antibody and T-cell receptor diversity through V(D)J recombination and somatic
                  hypermutation
                </li>
                <li>
                  <strong className="text-foreground">Host-Pathogen Arms Races:</strong> Investigating the
                  coevolutionary dynamics between immune defenses and pathogen evasion strategies
                </li>
                <li>
                  <strong className="text-foreground">Immune System Evolution:</strong> Comparing immune mechanisms
                  across species to understand the evolutionary origins and constraints of immunity
                </li>
                <li>
                  <strong className="text-foreground">Autoimmunity and Trade-offs:</strong> Examining how evolutionary
                  trade-offs between pathogen defense and self-tolerance lead to autoimmune diseases
                </li>
                <li>
                  <strong className="text-foreground">Clonal Selection Dynamics:</strong> Modeling the evolutionary
                  dynamics of lymphocyte populations during immune responses and immunological memory formation
                </li>
              </ul>

              <h3 className="mt-8 text-xl font-bold">Methodological Approaches</h3>
              <p className="text-muted-foreground leading-relaxed">
                We use immune repertoire sequencing to track the evolution of B and T cell populations, comparative
                genomics to understand immune system evolution across species, and mathematical modeling to predict
                immune response dynamics. Our work integrates immunology with evolutionary theory and population
                genetics.
              </p>

              <h3 className="mt-8 text-xl font-bold">Current Projects</h3>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Vaccine Response Evolution</CardTitle>
                    <CardDescription>
                      Tracking the evolutionary dynamics of antibody responses to vaccination and predicting long-term
                      immunity
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Cancer Immunoediting</CardTitle>
                    <CardDescription>
                      Understanding how tumors evolve to escape immune surveillance and how to leverage evolutionary
                      principles for immunotherapy
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Innate Immunity Evolution</CardTitle>
                    <CardDescription>
                      Investigating the evolutionary conservation and diversification of pattern recognition receptors
                      across species
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Publications</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Read our research on immune evolution, repertoire dynamics, and host-pathogen coevolution.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Publications
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <FlaskConical className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Immunology Partners</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Learn about our collaborations with immunology labs and clinical research centers.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Partnerships
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Collaborators</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Meet the researchers working on immunity evolution projects.
                </p>
                <Button asChild className="mt-4 w-full bg-transparent" variant="outline">
                  <Link href="/collaborations">View Team</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
