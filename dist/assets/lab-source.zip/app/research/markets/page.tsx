import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, BookOpen, FlaskConical, Users } from "lucide-react"

export default function MarketsPage() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <Button asChild variant="ghost" className="mb-8">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
        </Button>

        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Evolution of Financial Markets</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Applying evolutionary theory to economic systems and market dynamics
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-2xl font-bold">Research Overview</h2>
              <p className="text-muted-foreground leading-relaxed">
                Financial markets exhibit evolutionary dynamics analogous to biological systems, with competing
                strategies, adaptation to changing environments, and selection pressures shaping market behavior. Our
                research applies evolutionary theory and population dynamics to understand and predict financial market
                phenomena.
              </p>

              <h3 className="mt-8 text-xl font-bold">Key Research Areas</h3>
              <ul className="mt-4 space-y-3 text-muted-foreground">
                <li>
                  <strong className="text-foreground">Trading Strategy Evolution:</strong> Modeling how investment
                  strategies compete, adapt, and evolve in response to market conditions and other strategies
                </li>
                <li>
                  <strong className="text-foreground">Market Ecology:</strong> Analyzing financial markets as ecosystems
                  with diverse agent types, resource competition, and predator-prey dynamics
                </li>
                <li>
                  <strong className="text-foreground">Innovation Diffusion:</strong> Studying how financial innovations
                  spread through markets and the evolutionary pressures that shape their adoption
                </li>
                <li>
                  <strong className="text-foreground">Regulatory Evolution:</strong> Understanding how market
                  regulations coevolve with trading practices and institutional structures
                </li>
                <li>
                  <strong className="text-foreground">Crisis Dynamics:</strong> Applying evolutionary models to
                  understand market crashes, bubbles, and systemic risk emergence
                </li>
              </ul>

              <h3 className="mt-8 text-xl font-bold">Methodological Approaches</h3>
              <p className="text-muted-foreground leading-relaxed">
                We employ agent-based modeling, evolutionary game theory, and network analysis to simulate market
                evolution. Our work integrates high-frequency trading data with theoretical models from population
                genetics and ecology to reveal fundamental principles governing market dynamics.
              </p>

              <h3 className="mt-8 text-xl font-bold">Current Projects</h3>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Algorithmic Trading Evolution</CardTitle>
                    <CardDescription>
                      Investigating how machine learning algorithms evolve and compete in modern high-frequency trading
                      environments
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Cryptocurrency Market Dynamics</CardTitle>
                    <CardDescription>
                      Applying evolutionary models to understand the emergence and competition of digital currencies and
                      DeFi protocols
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Behavioral Finance Evolution</CardTitle>
                    <CardDescription>
                      Modeling how cognitive biases and heuristics evolve under market selection pressures
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Publications</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Explore our research on market evolution, trading dynamics, and financial innovation.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Publications
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <FlaskConical className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Industry Partnerships</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Learn about our collaborations with financial institutions and fintech companies.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Partnerships
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Collaborators</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Meet the researchers working on financial market evolution projects.
                </p>
                <Button asChild className="mt-4 w-full bg-transparent" variant="outline">
                  <Link href="/collaborations">View Team</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
