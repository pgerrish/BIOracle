import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, BookOpen, FlaskConical, Users } from "lucide-react"

export default function ForecastingPage() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <Button asChild variant="ghost" className="mb-8">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
        </Button>

        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Evolutionary Forecasting</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Leveraging evolutionary principles to forecast future states of large noisy systems
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-2xl font-bold">Research Overview</h2>
              <p className="text-muted-foreground leading-relaxed">
                Evolutionary forecasting applies principles from evolutionary theory to predict the future states of
                complex, dynamic systems. By treating systems as evolving populations subject to selection, drift, and
                mutation-like processes, we develop robust predictive models that account for uncertainty and adaptation
                in noisy environments.
              </p>

              <h3 className="mt-8 text-xl font-bold">Key Research Areas</h3>
              <ul className="mt-4 space-y-3 text-muted-foreground">
                <li>
                  <strong className="text-foreground">Adaptive Forecasting Models:</strong> Developing prediction
                  frameworks that evolve with changing system dynamics and learn from forecast errors
                </li>
                <li>
                  <strong className="text-foreground">Population-Level Predictions:</strong> Forecasting aggregate
                  behaviors in large systems by modeling individual-level variation and selection pressures
                </li>
                <li>
                  <strong className="text-foreground">Evolutionary Game Theory:</strong> Predicting strategic
                  interactions and equilibria in competitive environments using evolutionary dynamics
                </li>
                <li>
                  <strong className="text-foreground">Phylogenetic Forecasting:</strong> Using evolutionary
                  relationships and historical patterns to predict future trait evolution and system trajectories
                </li>
                <li>
                  <strong className="text-foreground">Noise-Robust Prediction:</strong> Developing forecasting methods
                  that maintain accuracy despite high levels of stochasticity and measurement uncertainty
                </li>
              </ul>

              <h3 className="mt-8 text-xl font-bold">Methodological Approaches</h3>
              <p className="text-muted-foreground leading-relaxed">
                We combine evolutionary algorithms, Bayesian inference, and machine learning to create forecasting
                systems that adapt to changing conditions. Our methods incorporate fitness landscapes, selection
                gradients, and evolutionary constraints to generate predictions that account for both deterministic
                trends and stochastic variation.
              </p>

              <h3 className="mt-8 text-xl font-bold">Current Projects</h3>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Market Evolution Forecasting</CardTitle>
                    <CardDescription>
                      Predicting financial market dynamics by modeling trading strategies as evolving populations
                      competing for resources
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Pathogen Trajectory Prediction</CardTitle>
                    <CardDescription>
                      Forecasting viral evolution and epidemic spread using phylodynamic models and evolutionary
                      constraints
                    </CardDescription>
                  </CardHeader>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Adaptive Climate Models</CardTitle>
                    <CardDescription>
                      Developing evolutionary forecasting approaches for ecological systems responding to environmental
                      change
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Publications</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Explore our research on evolutionary forecasting methods and applications across diverse systems.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Publications
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <FlaskConical className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Forecasting Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Access our open-source forecasting frameworks and computational tools.
                </p>
                <Button className="mt-4 w-full bg-transparent" variant="outline">
                  View Tools
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Collaborators</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Meet the researchers working on evolutionary forecasting projects.
                </p>
                <Button asChild className="mt-4 w-full bg-transparent" variant="outline">
                  <Link href="/collaborations">View Team</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
