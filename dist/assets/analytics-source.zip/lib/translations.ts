export const translations = {
  en: {
    nav: {
      home: "Home",
      research: "Research",
      members: "Members",
      publications: "Publications",
      consulting: "Consulting",
      contact: "Contact",
      language: "Language",
    },
    home: {
      hero: {
        title: "Taming Risk Through",
        titleAccent: "Predictive Evolution",
        subtitle:
          "A research collective advancing mathematical and computational frameworks for containment strategies, evolutionary prediction, and risk assessment in synthetic biology, emerging pathogens, gain-of-function studies, financial markets, and AI autonomous algorithmic evolution",
        exploreResearch: "Explore Our Research",
        consultingServices: "Consulting Services",
      },
      coreResearch: {
        title: "Core Research Areas",
        subtitle: "Combining theoretical evolutionary genetics with advanced mathematical modeling",
        containment: {
          title: "Containment Frameworks",
          description: "Mathematical models for setting containment expiration dates and assessing barrier integrity",
        },
        killSwitch: {
          title: "Kill-Switch Evolution",
          description: "Predicting and preventing evolutionary escape from bacterial safety mechanisms",
        },
        spillover: {
          title: "Spillover Risk Analysis",
          description: "Quantifying ecological and immunological interaction risks in novel systems",
        },
        targets: {
          title: "Evolutionary Targets",
          description: "Identifying and monitoring specific evolutionary trajectories of concern",
        },
      },
      about: {
        title: "Leading Mathematical Biosecurity Research",
        p1: "Our research group brings together faculty, postdocs, and graduate students with expertise in theoretical evolutionary genetics and mathematical modeling, applying rigorous analytical methods to critical biosecurity challenges.",
        p2: "We collaborate with international partners to develop predictive frameworks that anticipate the near-future course of evolution in engineered biological systems, establishing new standards for quantitative risk assessment in synthetic biology.",
        meetTeam: "Meet Our Team",
        activeResearchers: "Active Researchers",
      },
      cta: {
        title: "Partner with Our Research Group",
        subtitle: "Request information, schedule consultations, or discuss collaboration opportunities",
        getInTouch: "Get in Touch",
      },
    },
    members: {
      title: "Our Research Team",
      subtitle: "Internationally recognized experts in evolutionary genetics, mathematical modeling, and biosecurity",
      faculty: "Faculty",
      postdoc: "Postdoc",
      gradStudent: "Graduate Student",
      viewProfile: "View Profile",
    },
    contact: {
      title: "Get in Touch",
      subtitle: "Contact us for research collaborations, consulting services, or general inquiries",
      form: {
        name: "Full Name",
        email: "Email Address",
        organization: "Organization",
        subject: "Subject",
        message: "Message",
        send: "Send Message",
        sending: "Sending...",
      },
      info: {
        title: "Contact Information",
        address: "Address",
        addressDetails: "Evolutionary Risk Analytics\nResearch Division\nBerlin, Germany",
        email: "Email",
        phone: "Phone",
      },
    },
    consulting: {
      title: "Consulting Services",
      subtitle: "Expert guidance on biosecurity, containment strategies, and evolutionary risk assessment",
      services: {
        title: "Our Services",
        riskAssessment: {
          title: "Biosecurity Risk Assessment",
          description:
            "Comprehensive evaluation of containment systems and evolutionary escape probabilities for synthetic biology projects",
        },
        containment: {
          title: "Containment Strategy Design",
          description:
            "Mathematical modeling to establish containment expiration dates and multi-layered safety protocols",
        },
        evolutionary: {
          title: "Evolutionary Prediction",
          description: "Advanced forecasting of near-future evolutionary trajectories in engineered biological systems",
        },
        regulatory: {
          title: "Regulatory Compliance",
          description: "Expert consultation on biosecurity regulations and safety standards for synthetic biology",
        },
      },
      process: {
        title: "Our Process",
        consultation: {
          title: "Initial Consultation",
          description: "We discuss your project requirements and biosecurity concerns",
        },
        assessment: {
          title: "Assessment & Analysis",
          description: "Our team conducts comprehensive mathematical modeling and risk evaluation",
        },
        recommendations: {
          title: "Recommendations",
          description: "We deliver detailed reports with actionable containment strategies",
        },
        support: {
          title: "Ongoing Support",
          description: "Continued monitoring and consultation as your project evolves",
        },
      },
      pricing: {
        title: "Pricing & Packages",
        basic: {
          name: "Basic Assessment",
          price: "$5,000 USD",
          description: "Initial risk evaluation and containment review",
          features: ["2-week turnaround", "Written report", "1 consultation session", "Email support"],
        },
        comprehensive: {
          name: "Comprehensive Analysis",
          price: "$15,000 USD",
          description: "In-depth modeling and multi-scenario assessment",
          features: [
            "4-week engagement",
            "Detailed mathematical models",
            "3 consultation sessions",
            "Priority support",
          ],
          popular: "Most Popular",
        },
        ongoing: {
          name: "Ongoing Partnership",
          price: "Custom",
          description: "Long-term collaboration and monitoring",
          features: ["Custom timeline", "Continuous monitoring", "Unlimited consultations", "Dedicated team"],
        },
      },
      cta: {
        title: "Ready to Get Started?",
        subtitle: "Contact us to discuss your project and receive a custom proposal",
        schedule: "Schedule Consultation",
        confidentiality: "All consultations are confidential and protected by NDAs",
      },
    },
    research: {
      title: "Research Focus",
      subtitle: "Advancing biosecurity through mathematical frameworks and evolutionary prediction",
      synbio: {
        title: "Synthetic Biology Context",
        description:
          "Synthetic biology enables precise engineering of biological systems, from modified bacteria to entirely novel organisms. While this field holds immense promise for medicine, agriculture, and environmental remediation, it also presents unique biosecurity challenges. Our research addresses the critical gap between engineered intent and evolutionary reality, developing mathematical frameworks to predict and prevent unintended consequences.",
        challenges: "Key Biosecurity Challenges",
        challenge1: "Evolutionary escape from designed containment systems",
        challenge2: "Gene transfer to natural organisms",
        challenge3: "Unexpected ecological interactions",
        challenge4: "Long-term stability of engineered traits",
      },
      areas: {
        containment: {
          title: "Predictive Containment Frameworks",
          description:
            "We develop mathematical models to establish scientifically grounded expiration dates for containment measures. Our frameworks integrate mutation rates, selection pressures, and population dynamics to predict when engineered safeguards may fail.",
          approaches: "Key Approaches",
          approach1: "Stochastic modeling of evolutionary trajectories",
          approach2: "Multi-barrier containment optimization",
          approach3: "Temporal risk assessment algorithms",
        },
        killSwitch: {
          title: "Kill-Switch Evolution",
          description:
            "Bacterial kill-switches are designed to eliminate engineered organisms outside controlled environments. However, evolutionary pressure can lead to escape mutants. Our research predicts mutation pathways and designs evolution-resistant safety mechanisms.",
          focus: "Research Focus",
          focus1: "Mutation rate analysis in safety circuits",
          focus2: "Selection pressure quantification",
          focus3: "Redundant kill-switch architecture",
        },
        spillover: {
          title: "Spillover Risk Assessment",
          description:
            "We quantify the probability and impact of engineered organisms interacting with natural ecosystems or immune systems. Our models integrate ecological theory, immunology, and evolutionary genetics.",
          metrics: "Risk Metrics",
          metric1: "Horizontal gene transfer probabilities",
          metric2: "Immune system interaction modeling",
          metric3: "Ecological niche overlap analysis",
        },
        interaction: {
          title: "Interaction Risk Modeling",
          description:
            "Complex interactions between engineered organisms and their environment can produce unexpected outcomes. We model immunological responses, ecological competition, and metabolic cross-talk.",
          areas: "Analysis Areas",
          area1: "Host immune response prediction",
          area2: "Microbial community dynamics",
          area3: "Metabolite exchange networks",
        },
        targets: {
          title: "Evolutionary Targets of Concern",
          description:
            "Certain evolutionary pathways pose heightened biosecurity risks. We identify and monitor specific genetic targets that could lead to containment failure or increased virulence.",
          surveillance: "Surveillance Focus",
          target1: "Antibiotic resistance emergence",
          target2: "Virulence factor acquisition",
          target3: "Host range expansion mutations",
        },
      },
    },
    publications: {
      title: "Publications",
      subtitle: "Recent research outputs and preprints",
      year: "Year",
      authors: "Authors",
      journal: "Journal",
      doi: "DOI",
      preprint: "Preprint",
      loading: "Loading publications...",
      noPublications: "No publications available at this time.",
    },
  },
  es: {
    nav: {
      home: "Inicio",
      research: "Investigación",
      members: "Miembros",
      publications: "Publicaciones",
      consulting: "Consultoría",
      contact: "Contacto",
      language: "Idioma",
    },
    home: {
      hero: {
        title: "Bioseguridad a Través de la",
        titleAccent: "Evolución Predictiva",
        subtitle:
          "Un colectivo de investigación que avanza marcos matemáticos para estrategias de contención, predicción evolutiva y evaluación de riesgos en biología sintética",
        exploreResearch: "Explorar Nuestra Investigación",
        consultingServices: "Servicios de Consultoría",
      },
      coreResearch: {
        title: "Áreas Principales de Investigación",
        subtitle: "Combinando genética evolutiva teórica con modelado matemático avanzado",
        containment: {
          title: "Marcos de Contención",
          description:
            "Modelos matemáticos para establecer fechas de expiración de contención y evaluar la integridad de las barreras",
        },
        killSwitch: {
          title: "Evolución de Interruptores de Seguridad",
          description: "Predicción y prevención del escape evolutivo de mecanismos de seguridad bacteriana",
        },
        spillover: {
          title: "Análisis de Riesgo de Desbordamiento",
          description: "Cuantificación de riesgos de interacción ecológica e inmunológica en sistemas novedosos",
        },
        targets: {
          title: "Objetivos Evolutivos",
          description: "Identificación y monitoreo de trayectorias evolutivas específicas de preocupación",
        },
      },
      about: {
        title: "Liderando la Investigación en Bioseguridad Matemática",
        p1: "Nuestro grupo de investigación reúne profesores, posdoctorados y estudiantes de posgrado con experiencia en genética evolutiva teórica y modelado matemático, aplicando métodos analíticos rigurosos a desafíos críticos de bioseguridad.",
        p2: "Colaboramos con socios internacionales para desarrollar marcos predictivos que anticipan el curso futuro cercano de la evolución en sistemas biológicos diseñados, estableciendo nuevos estándares para la evaluación cuantitativa de riesgos en biología sintética.",
        meetTeam: "Conoce a Nuestro Equipo",
        activeResearchers: "Investigadores Activos",
      },
      cta: {
        title: "Asóciese con Nuestro Grupo de Investigación",
        subtitle: "Solicite información, programe consultas o discuta oportunidades de colaboración",
        getInTouch: "Póngase en Contacto",
      },
    },
    members: {
      title: "Nuestro Equipo de Investigación",
      subtitle: "Expertos reconocidos internacionalmente en genética evolutiva, modelado matemático y bioseguridad",
      faculty: "Profesorado",
      postdoc: "Posdoctorado",
      gradStudent: "Estudiante de Posgrado",
      viewProfile: "Ver Perfil",
    },
    contact: {
      title: "Póngase en Contacto",
      subtitle: "Contáctenos para colaboraciones de investigación, servicios de consultoría o consultas generales",
      form: {
        name: "Nombre Completo",
        email: "Correo Electrónico",
        organization: "Organización",
        subject: "Asunto",
        message: "Mensaje",
        send: "Enviar Mensaje",
        sending: "Enviando...",
      },
      info: {
        title: "Información de Contacto",
        address: "Dirección",
        addressDetails: "Evolutionary Risk Analytics\nResearch Division\nBerlin, Germany",
        email: "Correo Electrónico",
        phone: "Teléfono",
      },
    },
    consulting: {
      title: "Servicios de Consultoría",
      subtitle: "Orientación experta en bioseguridad, estrategias de contención y evaluación de riesgos evolutivos",
      services: {
        title: "Nuestros Servicios",
        riskAssessment: {
          title: "Evaluación de Riesgo de Bioseguridad",
          description:
            "Evaluación integral de sistemas de contención y probabilidades de escape evolutivo para proyectos de biología sintética",
        },
        containment: {
          title: "Diseño de Estrategia de Contención",
          description:
            "Modelado matemático para establecer fechas de expiración de contención y protocolos de seguridad multicapa",
        },
        evolutionary: {
          title: "Predicción Evolutiva",
          description:
            "Pronóstico avanzado de trayectorias evolutivas del futuro cercano en sistemas biológicos diseñados",
        },
        regulatory: {
          title: "Cumplimiento Normativo",
          description:
            "Consultoría experta sobre regulaciones de bioseguridad y estándares de seguridad para biología sintética",
        },
      },
      process: {
        title: "Nuestro Proceso",
        consultation: {
          title: "Consulta Inicial",
          description: "Discutimos los requisitos de su proyecto y las preocupaciones de bioseguridad",
        },
        assessment: {
          title: "Evaluación y Análisis",
          description: "Nuestro equipo realiza modelado matemático integral y evaluación de riesgos",
        },
        recommendations: {
          title: "Recomendaciones",
          description: "Entregamos informes detallados con estrategias de contención accionables",
        },
        support: {
          title: "Apoyo Continuo",
          description: "Monitoreo y consultoría continuos a medida que evoluciona su proyecto",
        },
      },
      pricing: {
        title: "Precios y Paquetes",
        basic: {
          name: "Evaluación Básica",
          price: "$5,000 USD",
          description: "Evaluación inicial de riesgos y revisión de contención",
          features: [
            "Entrega en 2 semanas",
            "Informe escrito",
            "1 sesión de consulta",
            "Soporte por correo electrónico",
          ],
        },
        comprehensive: {
          name: "Análisis Integral",
          price: "$15,000 USD",
          description: "Modelado en profundidad y evaluación de múltiples escenarios",
          features: [
            "Compromiso de 4 semanas",
            "Modelos matemáticos detallados",
            "3 sesiones de consulta",
            "Soporte prioritario",
          ],
          popular: "Más Popular",
        },
        ongoing: {
          name: "Asociación Continua",
          price: "Personalizado",
          description: "Colaboración y monitoreo a largo plazo",
          features: ["Cronograma personalizado", "Monitoreo continuo", "Consultas ilimitadas", "Equipo dedicado"],
        },
      },
      cta: {
        title: "¿Listo para Comenzar?",
        subtitle: "Contáctenos para discutir su proyecto y recibir una propuesta personalizada",
        schedule: "Programar Consulta",
        confidentiality: "Todas las consultas son confidenciales y protegidas por acuerdos de confidencialidad",
      },
    },
    research: {
      title: "Enfoque de Investigación",
      subtitle: "Avanzando la bioseguridad a través de marcos matemáticos y predicción evolutiva",
      synbio: {
        title: "Contexto de Biología Sintética",
        description:
          "La biología sintética permite la ingeniería precisa de sistemas biológicos, desde bacterias modificadas hasta organismos completamente novedosos. Si bien este campo tiene un enorme potencial para la medicina, la agricultura y la remediación ambiental, también presenta desafíos únicos de bioseguridad. Nuestra investigación aborda la brecha crítica entre la intención diseñada y la realidad evolutiva, desarrollando marcos matemáticos para predecir y prevenir consecuencias no deseadas.",
        challenges: "Desafíos Clave de Bioseguridad",
        challenge1: "Escape evolutivo de sistemas de contención diseñados",
        challenge2: "Transferencia de genes a organismos naturales",
        challenge3: "Interacciones ecológicas inesperadas",
        challenge4: "Estabilidad a largo plazo de rasgos diseñados",
      },
      areas: {
        containment: {
          title: "Marcos de Contención Predictivos",
          description:
            "Desarrollamos modelos matemáticos para establecer fechas de expiración científicamente fundamentadas para medidas de contención. Nuestros marcos integran tasas de mutación, presiones de selección y dinámicas poblacionales para predecir cuándo las salvaguardas diseñadas pueden fallar.",
          approaches: "Enfoques Clave",
          approach1: "Modelado estocástico de trayectorias evolutivas",
          approach2: "Optimización de contención de múltiples barreras",
          approach3: "Algoritmos de evaluación de riesgo temporal",
        },
        killSwitch: {
          title: "Evolución de Interruptores de Seguridad",
          description:
            "Los interruptores de seguridad bacterianos están diseñados para eliminar organismos diseñados fuera de entornos controlados. Sin embargo, la presión evolutiva puede conducir a mutantes de escape. Nuestra investigación predice vías de mutación y diseña mecanismos de seguridad resistentes a la evolución.",
          focus: "Enfoque de Investigación",
          focus1: "Análisis de tasa de mutación en circuitos de seguridad",
          focus2: "Cuantificación de presión de selección",
          focus3: "Arquitectura de interruptores de seguridad redundantes",
        },
        spillover: {
          title: "Evaluación de Riesgo de Desbordamiento",
          description:
            "Cuantificamos la probabilidad e impacto de organismos diseñados que interactúan con ecosistemas naturales o sistemas inmunes. Nuestros modelos integran teoría ecológica, inmunología y genética evolutiva.",
          metrics: "Métricas de Riesgo",
          metric1: "Probabilidades de transferencia horizontal de genes",
          metric2: "Modelado de interacción del sistema inmune",
          metric3: "Análisis de superposición de nicho ecológico",
        },
        interaction: {
          title: "Modelado de Riesgo de Interacción",
          description:
            "Las interacciones complejas entre organismos diseñados y su entorno pueden producir resultados inesperados. Modelamos respuestas inmunológicas, competencia ecológica y comunicación metabólica.",
          areas: "Áreas de Análisis",
          area1: "Predicción de respuesta inmune del huésped",
          area2: "Dinámica de comunidades microbianas",
          area3: "Redes de intercambio de metabolitos",
        },
        targets: {
          title: "Objetivos Evolutivos de Preocupación",
          description:
            "Ciertas vías evolutivas plantean riesgos de bioseguridad elevados. Identificamos y monitoreamos objetivos genéticos específicos que podrían conducir a fallas de contención o aumento de virulencia.",
          surveillance: "Enfoque de Vigilancia",
          target1: "Emergencia de resistencia a antibióticos",
          target2: "Adquisición de factores de virulencia",
          target3: "Mutaciones de expansión del rango de huéspedes",
        },
      },
    },
    publications: {
      title: "Publicaciones",
      subtitle: "Resultados de investigación recientes y preimpresiones",
      year: "Año",
      authors: "Autores",
      journal: "Revista",
      doi: "DOI",
      preprint: "Preimpresión",
      loading: "Cargando publicaciones...",
      noPublications: "No hay publicaciones disponibles en este momento.",
    },
  },
  pt: {
    nav: {
      home: "Início",
      research: "Pesquisa",
      members: "Membros",
      publications: "Publicações",
      consulting: "Consultoria",
      contact: "Contato",
      language: "Idioma",
    },
    home: {
      hero: {
        title: "Biossegurança Através da",
        titleAccent: "Evolução Preditiva",
        subtitle:
          "Um coletivo de pesquisa avançando estruturas matemáticas para estratégias de contenção, previsão evolutiva e avaliação de riscos em biologia sintética",
        exploreResearch: "Explore Nossa Pesquisa",
        consultingServices: "Serviços de Consultoria",
      },
      coreResearch: {
        title: "Áreas Principais de Pesquisa",
        subtitle: "Combinando genética evolutiva teórica com modelagem matemática avançada",
        containment: {
          title: "Estruturas de Contenção",
          description:
            "Modelos matemáticos para definir datas de expiração de contenção e avaliar integridade de barreiras",
        },
        killSwitch: {
          title: "Evolução de Interruptores de Segurança",
          description: "Previsão e prevenção de escape evolutivo de mecanismos de segurança bacteriana",
        },
        spillover: {
          title: "Análise de Risco de Transbordamento",
          description: "Quantificação de riscos de interação ecológica e imunológica em sistemas novos",
        },
        targets: {
          title: "Alvos Evolutivos",
          description: "Identificação e monitoramento de trajetórias evolutivas específicas de preocupação",
        },
      },
      about: {
        title: "Liderando a Pesquisa em Biossegurança Matemática",
        p1: "Nosso grupo de pesquisa reúne professores, pós-doutorandos e estudantes de pós-graduação com expertise em genética evolutiva teórica e modelagem matemática, aplicando métodos analíticos rigorosos a desafios críticos de biossegurança.",
        p2: "Colaboramos com parceiros internacionais para desenvolver estruturas preditivas que antecipam o curso futuro próximo da evolução em sistemas biológicos projetados, estabelecendo novos padrões para avaliação quantitativa de riscos em biologia sintética.",
        meetTeam: "Conheça Nossa Equipe",
        activeResearchers: "Pesquisadores Ativos",
      },
      cta: {
        title: "Faça Parceria com Nosso Grupo de Pesquisa",
        subtitle: "Solicite informações, agende consultas ou discuta oportunidades de colaboração",
        getInTouch: "Entre em Contato",
      },
    },
    members: {
      title: "Nossa Equipe de Pesquisa",
      subtitle:
        "Especialistas reconhecidos internacionalmente em genética evolutiva, modelagem matemática e biossegurança",
      faculty: "Professor",
      postdoc: "Pós-doutorado",
      gradStudent: "Estudante de Pós-graduação",
      viewProfile: "Ver Perfil",
    },
    contact: {
      title: "Entre em Contato",
      subtitle: "Entre em contato conosco para colaborações de pesquisa, serviços de consultoria ou consultas gerais",
      form: {
        name: "Nome Completo",
        email: "Endereço de E-mail",
        organization: "Organização",
        subject: "Assunto",
        message: "Mensagem",
        send: "Enviar Mensagem",
        sending: "Enviando...",
      },
      info: {
        title: "Informações de Contato",
        address: "Endereço",
        addressDetails: "Evolutionary Risk Analytics\nDivisão de Pesquisa\nBerlim, Alemanha",
        email: "E-mail",
        phone: "Telefone",
      },
    },
    consulting: {
      title: "Serviços de Consultoria",
      subtitle: "Orientação especializada em biossegurança, estratégias de contenção e avaliação de riscos evolutivos",
      services: {
        title: "Nossos Serviços",
        riskAssessment: {
          title: "Avaliação de Risco de Biossegurança",
          description:
            "Avaliação abrangente de sistemas de contenção e probabilidades de escape evolutivo para projetos de biologia sintética",
        },
        containment: {
          title: "Design de Estratégia de Contenção",
          description:
            "Modelagem matemática para estabelecer datas de expiração de contenção e protocolos de segurança multicamadas",
        },
        evolutionary: {
          title: "Previsão Evolutiva",
          description:
            "Previsão avançada de trajetórias evolutivas de futuro próximo em sistemas biológicos projetados",
        },
        regulatory: {
          title: "Conformidade Regulatória",
          description:
            "Consultoria especializada sobre regulamentações de biossegurança e padrões de segurança para biologia sintética",
        },
      },
      process: {
        title: "Nosso Processo",
        consultation: {
          title: "Consulta Inicial",
          description: "Discutimos os requisitos do seu projeto e preocupações com biossegurança",
        },
        assessment: {
          title: "Avaliação e Análise",
          description: "Nossa equipe realiza modelagem matemática abrangente e avaliação de riscos",
        },
        recommendations: {
          title: "Recomendações",
          description: "Entregamos relatórios detalhados com estratégias de contenção acionáveis",
        },
        support: {
          title: "Suporte Contínuo",
          description: "Monitoramento e consultoria contínuos à medida que seu projeto evolui",
        },
      },
      pricing: {
        title: "Preços e Pacotes",
        basic: {
          name: "Avaliação Básica",
          price: "$5.000 USD",
          description: "Avaliação inicial de riscos e revisão de contenção",
          features: ["Prazo de 2 semanas", "Relatório escrito", "1 sessão de consulta", "Suporte por e-mail"],
        },
        comprehensive: {
          name: "Análise Abrangente",
          price: "$15.000 USD",
          description: "Modelagem aprofundada e avaliação de múltiplos cenários",
          features: [
            "Engajamento de 4 semanas",
            "Modelos matemáticos detalhados",
            "3 sessões de consulta",
            "Suporte prioritário",
          ],
          popular: "Mais Popular",
        },
        ongoing: {
          name: "Parceria Contínua",
          price: "Personalizado",
          description: "Colaboração e monitoramento de longo prazo",
          features: ["Cronograma personalizado", "Monitoramento contínuo", "Consultas ilimitadas", "Equipe dedicada"],
        },
      },
      cta: {
        title: "Pronto para Começar?",
        subtitle: "Entre em contato conosco para discutir seu projeto e receber uma proposta personalizada",
        schedule: "Agendar Consulta",
        confidentiality: "Todas as consultas são confidenciais e protegidas por acordos de confidencialidade",
      },
    },
    research: {
      title: "Foco de Pesquisa",
      subtitle: "Avançando a biossegurança através de estruturas matemáticas e previsão evolutiva",
      synbio: {
        title: "Contexto de Biologia Sintética",
        description:
          "A biologia sintética permite a engenharia precisa de sistemas biológicos, desde bactérias modificadas até organismos completamente novos. Embora este campo tenha um enorme potencial para medicina, agricultura e remediação ambiental, também apresenta desafios únicos de biossegurança. Nossa pesquisa aborda a lacuna crítica entre intenção projetada e realidade evolutiva, desenvolvendo estruturas matemáticas para prever e prevenir consequências não intencionais.",
        challenges: "Principais Desafios de Biossegurança",
        challenge1: "Escape evolutivo de sistemas de contenção projetados",
        challenge2: "Transferência de genes para organismos naturais",
        challenge3: "Interações ecológicas inesperadas",
        challenge4: "Estabilidade a longo prazo de características projetadas",
      },
      areas: {
        containment: {
          title: "Estruturas de Contenção Preditivas",
          description:
            "Desenvolvemos modelos matemáticos para estabelecer datas de expiração cientificamente fundamentadas para medidas de contenção. Nossas estruturas integram taxas de mutação, pressões de seleção e dinâmicas populacionais para prever quando as salvaguardas projetadas podem falhar.",
          approaches: "Principais Abordagens",
          approach1: "Modelagem estocástica de trajetórias evolutivas",
          approach2: "Otimização de contenção de múltiplas barreiras",
          approach3: "Algoritmos de avaliação de risco temporal",
        },
        killSwitch: {
          title: "Evolução de Interruptores de Segurança",
          description:
            "Interruptores de segurança bacterianos são projetados para eliminar organismos projetados fora de ambientes controlados. No entanto, pressão evolutiva pode levar a mutantes de escape. Nossa pesquisa prevê vias de mutação e projeta mecanismos de segurança resistentes à evolução.",
          focus: "Foco de Pesquisa",
          focus1: "Análise de taxa de mutação em circuitos de segurança",
          focus2: "Quantificação de pressão de seleção",
          focus3: "Arquitetura de interruptores de segurança redundantes",
        },
        spillover: {
          title: "Avaliação de Risco de Transbordamento",
          description:
            "Quantificamos a probabilidade e impacto de organismos projetados interagindo com ecossistemas naturais ou sistemas imunológicos. Nossos modelos integram teoria ecológica, imunologia e genética evolutiva.",
          metrics: "Métricas de Risco",
          metric1: "Probabilidades de transferência horizontal de genes",
          metric2: "Modelagem de interação do sistema imunológico",
          metric3: "Análise de sobreposição de nicho ecológico",
        },
        interaction: {
          title: "Modelagem de Risco de Interação",
          description:
            "Interações complexas entre organismos projetados e seu ambiente podem produzir resultados inesperados. Modelamos respostas imunológicas, competição ecológica e comunicação metabólica.",
          areas: "Áreas de Análise",
          area1: "Previsão de resposta imune do hospedeiro",
          area2: "Dinâmica de comunidades microbianas",
          area3: "Redes de troca de metabólitos",
        },
        targets: {
          title: "Alvos Evolutivos de Preocupação",
          description:
            "Certas vias evolutivas apresentam riscos elevados de biossegurança. Identificamos e monitoramos alvos genéticos específicos que podem levar a falhas de contenção ou aumento de virulência.",
          surveillance: "Foco de Vigilância",
          target1: "Emergência de resistência a antibióticos",
          target2: "Aquisição de fatores de virulência",
          target3: "Mutações de expansão do alcance do hospedeiro",
        },
      },
    },
    publications: {
      title: "Publicações",
      subtitle: "Resultados de pesquisa recentes e pré-impressões",
      year: "Ano",
      authors: "Autores",
      journal: "Revista",
      doi: "DOI",
      preprint: "Pré-impressão",
      loading: "Carregando publicações...",
      noPublications: "Nenhuma publicação disponível no momento.",
    },
  },
}
