"use client"

import Link from "next/link"
import { Linkedin, Twitter, Mail } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

export function Footer() {
  const { t } = useLanguage()

  return (
    <footer className="glass-dark-heavy">
      <div className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <h3 className="font-serif text-xl font-light tracking-wide text-white">Evolutionary Risk Analytics</h3>
            <p className="mt-4 text-sm leading-relaxed text-gray-500 max-w-md">
              Rigorous mathematical frameworks for biosecurity and containment in synthetic biology. Precision-driven
              research in evolutionary risk assessment and predictive modeling.
            </p>
            <div className="mt-6 flex gap-4">
              <a href="#" className="text-gray-500 hover:text-amber-400 transition-colors" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-amber-400 transition-colors" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="mailto:contact@example.com" className="text-gray-500 hover:text-amber-400 transition-colors" aria-label="Email">
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-xs font-medium uppercase tracking-widest text-gray-400">{t("nav.research")}</h4>
            <ul className="mt-4 space-y-2">
              <li>
                <Link href="/research" className="text-sm text-gray-500 hover:text-amber-400 transition-colors">
                  Focus Areas
                </Link>
              </li>
              <li>
                <Link href="/publications" className="text-sm text-gray-500 hover:text-amber-400 transition-colors">
                  {t("nav.publications")}
                </Link>
              </li>
              <li>
                <Link href="/members" className="text-sm text-gray-500 hover:text-amber-400 transition-colors">
                  {t("nav.members")}
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-xs font-medium uppercase tracking-widest text-gray-400">Services</h4>
            <ul className="mt-4 space-y-2">
              <li>
                <Link href="/consulting" className="text-sm text-gray-500 hover:text-amber-400 transition-colors">
                  {t("nav.consulting")}
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-sm text-gray-500 hover:text-amber-400 transition-colors">
                  {t("nav.contact")}
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-white/10 pt-8">
          <p className="text-center text-xs tracking-wider uppercase text-gray-600">
            &copy; {new Date().getFullYear()} Evolutionary Risk Analytics. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
