"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, Globe } from "lucide-react"
import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const navigation = [
  { name: "home", href: "/" },
  { name: "research", href: "/research" },
  { name: "members", href: "/members" },
  { name: "publications", href: "/publications" },
  { name: "consulting", href: "/consulting" },
  { name: "contact", href: "/contact" },
]

export function Nav() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { language, setLanguage, t } = useLanguage()

  useEffect(() => {
    setMobileMenuOpen(false)
  }, [pathname])

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [mobileMenuOpen])

  const LanguageSwitcher = () => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-amber-400 gap-2">
          <Globe className="h-4 w-4" />
          <span className="text-xs uppercase tracking-wider">{language}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="glass-dark border-white/10">
        <DropdownMenuItem
          onClick={() => setLanguage("en")}
          className="text-gray-300 hover:text-white hover:bg-white/10"
        >
          English
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setLanguage("es")}
          className="text-gray-300 hover:text-white hover:bg-white/10"
        >
          {"Espa\u00f1ol"}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setLanguage("pt")}
          className="text-gray-300 hover:text-white hover:bg-white/10"
        >
          {"Portugu\u00eas"}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )

  return (
    <>
      <header className="sticky top-0 z-50 glass-dark">
        <nav className="mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8" aria-label="Global">
          <div className="flex lg:flex-1">
            <Link href="/" className="-m-1.5 p-1.5">
              <span className="font-serif text-2xl font-light tracking-wide text-white">
                Evolutionary <span className="text-amber-400">Risk Analytics</span>
              </span>
            </Link>
          </div>

          <div className="flex lg:hidden">
            <button
              type="button"
              className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-400 hover:text-white"
              onClick={() => setMobileMenuOpen(true)}
            >
              <span className="sr-only">Open main menu</span>
              <Menu className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>

          <div className="hidden lg:flex lg:gap-x-8 lg:items-center">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "text-sm font-light tracking-wider uppercase transition-colors hover:text-amber-400",
                  pathname === item.href ? "text-amber-400" : "text-gray-400",
                )}
              >
                {t(`nav.${item.name}`)}
              </Link>
            ))}
            <LanguageSwitcher />
          </div>
        </nav>
      </header>

      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)} />
          <div className="fixed inset-y-0 right-0 w-full max-w-sm glass-dark-heavy overflow-y-auto">
            <div className="px-6 py-6">
              <div className="flex items-center justify-between mb-8">
                <Link href="/" className="-m-1.5 p-1.5" onClick={() => setMobileMenuOpen(false)}>
                  <span className="font-serif text-xl font-light tracking-wide text-white">
                    Evolutionary <span className="text-amber-400">Risk Analytics</span>
                  </span>
                </Link>
                <button
                  type="button"
                  className="-m-2.5 rounded-md p-2.5 text-gray-400 hover:text-white"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="sr-only">Close menu</span>
                  <X className="h-6 w-6" aria-hidden="true" />
                </button>
              </div>
              <div className="space-y-1 mb-8">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "block rounded-lg px-3 py-3 text-base font-light tracking-wider uppercase transition-colors",
                      pathname === item.href
                        ? "bg-white/10 text-amber-400"
                        : "text-gray-400 hover:bg-white/5 hover:text-white",
                    )}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {t(`nav.${item.name}`)}
                  </Link>
                ))}
              </div>
              <div className="border-t border-white/10 pt-6">
                <p className="text-xs text-gray-500 mb-3 px-3 uppercase tracking-wider">{t("nav.language")}</p>
                <div className="space-y-1">
                  {[
                    { code: "en" as const, label: "English" },
                    { code: "es" as const, label: "Espa\u00f1ol" },
                    { code: "pt" as const, label: "Portugu\u00eas" },
                  ].map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => setLanguage(lang.code)}
                      className={cn(
                        "block w-full text-left rounded-lg px-3 py-3 text-base font-light tracking-wider transition-colors",
                        language === lang.code
                          ? "bg-white/10 text-amber-400"
                          : "text-gray-400 hover:bg-white/5 hover:text-white",
                      )}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
