"use client"

import { useEffect, useState } from "react"

export function ParallaxBackground() {
  const [offset, setOffset] = useState(0)

  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)")
    if (mediaQuery.matches) return

    let frame = 0
    const updateOffset = () => {
      frame = 0
      setOffset(window.scrollY * 0.22)
    }

    const handleScroll = () => {
      if (!frame) frame = window.requestAnimationFrame(updateOffset)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => {
      window.removeEventListener("scroll", handleScroll)
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  return (
    <div
      aria-hidden="true"
      className="parallax-layer"
      style={{ transform: `translate3d(0, ${-offset}px, 0)` }}
    />
  )
}
