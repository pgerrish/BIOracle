"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Dna, Shield, TrendingUp, Users } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

export default function Home() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-32 sm:py-40">
        <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12 sm:py-20 lg:px-16">
            <div className="max-w-3xl">
              <h1 className="font-serif text-5xl font-light tracking-wide text-white sm:text-7xl leading-tight">
                {t("home.hero.title")}
                <br />
                <span className="text-amber-400">{t("home.hero.titleAccent")}</span>
              </h1>
              <p className="mt-8 pl-1 text-lg leading-relaxed text-gray-400 max-w-2xl text-pretty">
                {t("home.hero.subtitle")}
              </p>
              <div className="mt-12 pl-1 flex flex-wrap items-center gap-4">
                <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-medium tracking-wide">
                  <Link href="/research">
                    {t("home.hero.exploreResearch")} <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10 bg-transparent font-light tracking-wide"
                >
                  <Link href="/consulting">{t("home.hero.consultingServices")}</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Research Focus Areas */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <div className="max-w-2xl mb-14">
              <h2 className="font-serif text-4xl font-light tracking-wide text-amber-100 sm:text-5xl">
                {t("home.coreResearch.title")}
              </h2>
              <p className="mt-4 pl-1 text-lg text-gray-400 text-pretty">{t("home.coreResearch.subtitle")}</p>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: Shield, key: "containment", accent: "bg-amber-500/20 text-amber-400" },
                { icon: Dna, key: "killSwitch", accent: "bg-white/10 text-gray-300" },
                { icon: TrendingUp, key: "spillover", accent: "bg-amber-500/15 text-amber-300" },
                { icon: Users, key: "targets", accent: "bg-white/10 text-gray-400" },
              ].map(({ icon: Icon, key, accent }) => (
                <div
                  key={key}
                  className="group rounded-lg border border-white/10 bg-white/5 p-6 hover:bg-white/10 transition-all"
                >
                  <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md ${accent}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="font-serif text-xl font-normal text-amber-100">
                    {t(`home.coreResearch.${key}.title`)}
                  </h3>
                  <p className="mt-2 text-sm text-gray-400 leading-relaxed">
                    {t(`home.coreResearch.${key}.description`)}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <div className="grid grid-cols-1 gap-16 lg:grid-cols-2 lg:gap-24">
              <div>
                <h2 className="font-serif text-4xl font-light tracking-wide text-amber-100 sm:text-5xl">
                  {t("home.about.title")}
                </h2>
                <p className="mt-8 pl-1 text-lg leading-relaxed text-gray-400">{t("home.about.p1")}</p>
                <p className="mt-4 pl-1 text-lg leading-relaxed text-gray-400">{t("home.about.p2")}</p>
                <div className="mt-10 pl-1">
                  <Button asChild size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10 font-light tracking-wide">
                    <Link href="/members">{t("home.about.meetTeam")}</Link>
                  </Button>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square overflow-hidden rounded-lg shadow-2xl">
                  <img
                    src="/mathematical-equations-dna-sequences-scientific-vi.jpg"
                    alt="Research visualization"
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -right-6 glass-dark-heavy rounded-lg p-6 shadow-xl">
                  <p className="font-serif text-4xl font-light text-amber-400">10+</p>
                  <p className="text-sm text-gray-400">{t("home.about.activeResearchers")}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <div className="max-w-2xl">
              <h2 className="font-serif text-4xl font-light tracking-wide text-white sm:text-5xl text-balance">
                {t("home.cta.title")}
              </h2>
              <p className="mt-4 pl-1 text-lg text-gray-400 text-pretty">{t("home.cta.subtitle")}</p>
              <div className="mt-10 pl-1">
                <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-medium tracking-wide">
                  <Link href="/contact">{t("home.cta.getInTouch")}</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
