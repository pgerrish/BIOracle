"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Mail, MapPin, Phone, Calendar } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

export default function ContactPage() {
  const { t } = useLanguage()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    organization: "",
    inquiryType: "",
    message: "",
  })
  const [sending, setSending] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSending(true)
    console.log("Form submitted:", formData)
    setTimeout(() => {
      alert("Thank you for your inquiry. We'll get back to you soon!")
      setFormData({ name: "", email: "", organization: "", inquiryType: "", message: "" })
      setSending(false)
    }, 1000)
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <h1 className="font-serif text-5xl font-light tracking-wide text-white sm:text-6xl">
              {t("contact.title")}
            </h1>
            <p className="mt-4 pl-1 text-lg text-gray-400 max-w-2xl text-pretty">{t("contact.subtitle")}</p>
          </div>
        </div>
      </section>

      {/* Contact Form and Info */}
      <section className="py-8">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card className="glass-dark border-white/10">
                <CardHeader>
                  <CardTitle className="font-serif text-2xl font-light tracking-wide text-amber-100">Send us a message</CardTitle>
                  <CardDescription className="text-gray-400">Fill out the form below and we{"'"}ll get back to you within 48 hours</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="font-light tracking-wide text-gray-300">{t("contact.form.name")}</Label>
                        <Input
                          id="name"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="John Doe"
                          className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="font-light tracking-wide text-gray-300">{t("contact.form.email")}</Label>
                        <Input
                          id="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="john@example.com"
                          className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="organization" className="font-light tracking-wide text-gray-300">{t("contact.form.organization")}</Label>
                      <Input
                        id="organization"
                        value={formData.organization}
                        onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                        placeholder="University or Company Name"
                        className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="inquiryType" className="font-light tracking-wide text-gray-300">{t("contact.form.subject")}</Label>
                      <Select
                        required
                        value={formData.inquiryType}
                        onValueChange={(value) => setFormData({ ...formData, inquiryType: value })}
                      >
                        <SelectTrigger className="border-white/10 bg-white/5 text-gray-200">
                          <SelectValue placeholder="Select inquiry type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="collaboration">Research Collaboration</SelectItem>
                          <SelectItem value="consulting">Consulting Services</SelectItem>
                          <SelectItem value="speaking">Speaking Engagement</SelectItem>
                          <SelectItem value="student">Student/PhD Inquiry</SelectItem>
                          <SelectItem value="media">Media Request</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message" className="font-light tracking-wide text-gray-300">{t("contact.form.message")}</Label>
                      <Textarea
                        id="message"
                        required
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="Tell us about your inquiry..."
                        rows={6}
                        className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide"
                      disabled={sending}
                    >
                      {sending ? t("contact.form.sending") : t("contact.form.send")}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <Card className="glass-dark border-white/10">
                <CardHeader>
                  <CardTitle className="font-serif text-xl font-light tracking-wide text-amber-100">{t("contact.info.title")}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="mr-3 h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-light text-gray-200">{t("contact.info.address")}</p>
                      <p className="text-sm text-gray-400 leading-relaxed whitespace-pre-line">
                        {t("contact.info.addressDetails")}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Mail className="mr-3 h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-light text-gray-200">{t("contact.info.email")}</p>
                      <a href="mailto:contact@evolutionaryrisk.de" className="text-sm text-amber-400 hover:underline">
                        contact@evolutionaryrisk.de
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Phone className="mr-3 h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-light text-gray-200">{t("contact.info.phone")}</p>
                      <p className="text-sm text-gray-400">+49 30 1234 5678</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-dark border-white/10">
                <CardHeader>
                  <CardTitle className="font-serif text-xl font-light tracking-wide text-amber-100 flex items-center">
                    <Calendar className="mr-2 h-5 w-5 text-amber-400" />
                    Schedule a Meeting
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-400 mb-4 leading-relaxed">
                    Prefer a direct conversation? Schedule a meeting with our team.
                  </p>
                  <Button asChild className="w-full bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
                    <a href="/consulting#schedule">Book a Consultation</a>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
