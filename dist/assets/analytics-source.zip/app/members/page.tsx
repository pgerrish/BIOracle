"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mail, GraduationCap } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

const members = [
  {
    id: "maria-rodriguez",
    name: "Dr. Maria Rodriguez",
    role: "Principal Investigator",
    position: "Professor",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Evolutionary Genetics", "Mathematical Modeling", "Containment Theory"],
    image: "/members/maria-rodriguez.jpg",
    email: "maria.rodriguez@example.com",
  },
  {
    id: "juan-garcia",
    name: "Dr. Juan Garcia",
    role: "Senior Researcher",
    position: "Associate Professor",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Kill-Switch Evolution", "Population Dynamics", "Stochastic Processes"],
    image: "/members/juan-garcia.jpg",
    email: "juan.garcia@example.com",
  },
  {
    id: "ana-lopez",
    name: "Dr. Ana Lopez",
    role: "Postdoctoral Researcher",
    position: "Postdoc",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Spillover Risk", "Network Analysis", "Ecological Modeling"],
    image: "/members/ana-lopez.jpg",
    email: "ana.lopez@example.com",
  },
  {
    id: "carlos-martinez",
    name: "Carlos Martinez",
    role: "Graduate Student",
    position: "PhD Candidate",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Computational Biology", "Bayesian Inference", "Risk Assessment"],
    image: "/members/carlos-martinez.jpg",
    email: "carlos.martinez@example.com",
  },
  {
    id: "sofia-hernandez",
    name: "Sofia Hernandez",
    role: "Graduate Student",
    position: "PhD Candidate",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Evolutionary Trajectories", "Game Theory", "Biocontainment"],
    image: "/members/sofia-hernandez.jpg",
    email: "sofia.hernandez@example.com",
  },
  {
    id: "david-chen",
    name: "Dr. David Chen",
    role: "Collaborator",
    position: "Associate Professor",
    department: "Biology",
    institution: "UC Berkeley",
    expertise: ["Synthetic Biology", "Biosafety", "Genetic Engineering"],
    image: "/members/david-chen.jpg",
    email: "david.chen@example.com",
  },
]

const roleOrder = {
  "Principal Investigator": 1,
  "Senior Researcher": 2,
  "Postdoctoral Researcher": 3,
  "Graduate Student": 4,
  Collaborator: 5,
}

const sortedMembers = [...members].sort((a, b) => {
  return roleOrder[a.role as keyof typeof roleOrder] - roleOrder[b.role as keyof typeof roleOrder]
})

export default function MembersPage() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <h1 className="font-serif text-5xl font-light tracking-wide text-white sm:text-6xl">
              {t("members.title")}
            </h1>
            <p className="mt-4 pl-1 text-lg text-gray-400 max-w-2xl text-pretty">{t("members.subtitle")}</p>
          </div>
        </div>
      </section>

      {/* Members Grid */}
      <section className="py-8">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {sortedMembers.map((member) => (
                <div
                  key={member.id}
                  className="group relative overflow-hidden rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 transition-all duration-300"
                >
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={member.image || "/placeholder.svg"}
                      alt={member.name}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <Badge variant="secondary" className="mb-3 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border-amber-500/20 font-light tracking-wider text-xs">
                      {member.role}
                    </Badge>
                    <h3 className="font-serif text-xl font-normal text-amber-100">{member.name}</h3>
                    <p className="mt-1 text-sm text-gray-400">
                      {member.position} &middot; {member.department}
                    </p>
                    <p className="text-sm text-gray-500">{member.institution}</p>

                    <div className="mt-4 flex flex-wrap gap-2">
                      {member.expertise.slice(0, 2).map((exp) => (
                        <Badge key={exp} variant="outline" className="text-xs border-white/15 text-gray-400 font-light">
                          {exp}
                        </Badge>
                      ))}
                      {member.expertise.length > 2 && (
                        <Badge variant="outline" className="text-xs border-white/15 text-gray-400 font-light">
                          +{member.expertise.length - 2} more
                        </Badge>
                      )}
                    </div>

                    <div className="mt-6 flex items-center gap-3">
                      <Button asChild size="sm" className="flex-1 bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
                        <Link href={`/members/${member.id}`}>{t("members.viewProfile")}</Link>
                      </Button>
                      <Button size="sm" variant="outline" asChild className="border-white/15 text-gray-400 hover:bg-white/10 hover:text-white">
                        <a href={`mailto:${member.email}`} aria-label={`Email ${member.name}`}>
                          <Mail className="h-4 w-4" />
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <GraduationCap className="h-10 w-10 text-amber-400 mb-6" />
            <h2 className="font-serif text-4xl font-light tracking-wide text-white sm:text-5xl max-w-xl text-balance">
              Join Our Research Group
            </h2>
            <p className="mt-4 pl-1 text-lg text-gray-400 max-w-xl text-pretty">
              We welcome collaborations and inquiries from researchers worldwide
            </p>
            <div className="mt-10 pl-1">
              <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-medium tracking-wide">
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
