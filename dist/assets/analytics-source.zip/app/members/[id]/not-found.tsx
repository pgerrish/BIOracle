import Link from "next/link"
import { Button } from "@/components/ui/button"
import { UserX } from "lucide-react"

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div className="glass-dark rounded-lg px-12 py-16 text-center">
        <UserX className="mx-auto h-16 w-16 text-gray-500" />
        <h1 className="mt-4 font-serif text-3xl font-light tracking-wide text-amber-100">Member Not Found</h1>
        <p className="mt-2 text-gray-400">The team member you{"'"}re looking for doesn{"'"}t exist.</p>
        <div className="mt-6">
          <Button asChild className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
            <Link href="/members">Back to Team</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
