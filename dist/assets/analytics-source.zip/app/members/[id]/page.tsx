import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Mail, Linkedin, Twitter, Globe, ArrowLeft, BookOpen, Award, Users } from "lucide-react"

// Member data - in production this would come from a database
const membersData = {
  "maria-rodriguez": {
    id: "maria-rodriguez",
    name: "Dr. Maria Rodriguez",
    role: "Principal Investigator",
    position: "Professor",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Evolutionary Genetics", "Mathematical Modeling", "Containment Theory"],
    image: "/members/maria-rodriguez.jpg",
    email: "maria.rodriguez@example.com",
    bio: "Dr. Rodriguez leads the research group with over 15 years of experience in theoretical evolutionary genetics. Her work focuses on developing predictive mathematical frameworks for biological containment systems. She received her PhD from Stanford University and has published over 60 peer-reviewed papers in evolutionary biology and mathematical modeling.",
    education: [
      { degree: "PhD in Applied Mathematics", institution: "Stanford University", year: "2008" },
      { degree: "MSc in Mathematical Biology", institution: "University of Oxford", year: "2004" },
      { degree: "BSc in Mathematics", institution: "LMU Munich", year: "2002" },
    ],
    selectedPublications: [
      {
        title: "Predictive frameworks for biocontainment expiration in engineered systems",
        journal: "Nature Biotechnology",
        year: "2024",
      },
      {
        title: "Mathematical analysis of kill-switch evolutionary stability",
        journal: "PLOS Computational Biology",
        year: "2023",
      },
      {
        title: "Stochastic models for synthetic gene circuit degradation",
        journal: "Molecular Systems Biology",
        year: "2022",
      },
    ],
    researchInterests: [
      "Containment expiration modeling",
      "Evolutionary prediction algorithms",
      "Biocontainment strategy optimization",
      "Risk assessment frameworks",
    ],
    website: "https://example.com/maria-rodriguez",
    twitter: "mrodriguez_bio",
    linkedin: "maria-rodriguez-phd",
  },
  "juan-garcia": {
    id: "juan-garcia",
    name: "Dr. Juan Garcia",
    role: "Senior Researcher",
    position: "Associate Professor",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Kill-Switch Evolution", "Population Dynamics", "Stochastic Processes"],
    image: "/members/juan-garcia.jpg",
    email: "juan.garcia@example.com",
    bio: "Dr. Garcia specializes in the evolutionary dynamics of bacterial kill-switches and safety mechanisms in synthetic biology. His research combines stochastic modeling with experimental validation to predict and prevent evolutionary escape from biocontainment systems.",
    education: [
      { degree: "PhD in Computational Biology", institution: "MIT", year: "2012" },
      { degree: "MSc in Applied Mathematics", institution: "TU Munich", year: "2008" },
      { degree: "BSc in Physics", institution: "Heidelberg University", year: "2006" },
    ],
    selectedPublications: [
      {
        title: "Evolutionary pathways to kill-switch failure in synthetic bacteria",
        journal: "Science Advances",
        year: "2024",
      },
      {
        title: "Population dynamics of engineered microorganisms under selection",
        journal: "Nature Communications",
        year: "2023",
      },
    ],
    researchInterests: [
      "Kill-switch robustness",
      "Mutation-selection balance",
      "Synthetic circuit evolution",
      "Biocontainment failure modes",
    ],
    website: "https://example.com/juan-garcia",
    linkedin: "juan-garcia-math",
  },
  "ana-lopez": {
    id: "ana-lopez",
    name: "Dr. Ana Lopez",
    role: "Postdoctoral Researcher",
    position: "Postdoc",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Spillover Risk", "Network Analysis", "Ecological Modeling"],
    image: "/members/ana-lopez.jpg",
    email: "ana.lopez@example.com",
    bio: "Dr. Lopez investigates spillover risks and ecological interactions of engineered organisms. Her research uses network theory and ecological modeling to assess potential impacts of synthetic biology on natural ecosystems and identify critical intervention points.",
    education: [
      { degree: "PhD in Ecology and Evolution", institution: "UC Berkeley", year: "2020" },
      { degree: "MSc in Environmental Science", institution: "ETH Zurich", year: "2016" },
      { degree: "BSc in Biology", institution: "Humboldt University Berlin", year: "2014" },
    ],
    selectedPublications: [
      {
        title: "Network-based assessment of engineered organism spillover potential",
        journal: "Ecology Letters",
        year: "2023",
      },
      { title: "Ecological risk factors in synthetic biology release", journal: "Trends in Ecology", year: "2022" },
    ],
    researchInterests: [
      "Ecological spillover modeling",
      "Host-pathogen interactions",
      "Biosafety risk assessment",
      "Community ecology of engineered systems",
    ],
    linkedin: "ana-lopez-ecology",
  },
  "carlos-martinez": {
    id: "carlos-martinez",
    name: "Carlos Martinez",
    role: "Graduate Student",
    position: "PhD Candidate",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Computational Biology", "Bayesian Inference", "Risk Assessment"],
    image: "/members/carlos-martinez.jpg",
    email: "carlos.martinez@example.com",
    bio: "Carlos is a PhD candidate developing Bayesian frameworks for biosecurity risk assessment. His dissertation focuses on probabilistic models for predicting evolutionary outcomes in synthetic biological systems under uncertainty.",
    education: [
      { degree: "PhD in Mathematics (in progress)", institution: "ERA Berlin", year: "Expected 2026" },
      { degree: "MSc in Applied Mathematics", institution: "TU Berlin", year: "2022" },
      { degree: "BSc in Mathematics", institution: "FU Berlin", year: "2020" },
    ],
    selectedPublications: [
      {
        title: "Bayesian approaches to containment uncertainty quantification",
        journal: "In preparation",
        year: "2025",
      },
    ],
    researchInterests: [
      "Bayesian risk modeling",
      "Uncertainty quantification",
      "Computational inference methods",
      "Decision theory in biosecurity",
    ],
  },
  "sofia-hernandez": {
    id: "sofia-hernandez",
    name: "Sofia Hernandez",
    role: "Graduate Student",
    position: "PhD Candidate",
    department: "Mathematics",
    institution: "ERA Berlin",
    expertise: ["Evolutionary Trajectories", "Game Theory", "Biocontainment"],
    image: "/members/sofia-hernandez.jpg",
    email: "sofia.hernandez@example.com",
    bio: "Sofia's research applies game theory to understand evolutionary strategies in biocontainment scenarios. She develops models to predict how engineered organisms might evolve under various selective pressures and containment strategies.",
    education: [
      { degree: "PhD in Mathematics (in progress)", institution: "ERA Berlin", year: "Expected 2025" },
      { degree: "MSc in Mathematical Biology", institution: "University of Bonn", year: "2021" },
      { degree: "BSc in Mathematics", institution: "Heidelberg University", year: "2019" },
    ],
    selectedPublications: [
      {
        title: "Game-theoretic models of evolutionary escape in synthetic systems",
        journal: "Journal of Theoretical Biology",
        year: "2024",
      },
    ],
    researchInterests: [
      "Evolutionary game theory",
      "Adaptive dynamics",
      "Strategic evolution modeling",
      "Containment strategy design",
    ],
  },
  "david-chen": {
    id: "david-chen",
    name: "Dr. David Chen",
    role: "Collaborator",
    position: "Associate Professor",
    department: "Biology",
    institution: "UC Berkeley",
    expertise: ["Synthetic Biology", "Biosafety", "Genetic Engineering"],
    image: "/members/david-chen.jpg",
    email: "david.chen@example.com",
    bio: "Dr. Chen is a synthetic biologist collaborating with the group to provide experimental validation of theoretical predictions. His lab specializes in engineering bacterial systems with enhanced safety features and testing evolutionary stability of biocontainment mechanisms.",
    education: [
      { degree: "PhD in Molecular Biology", institution: "Harvard University", year: "2010" },
      { degree: "BSc in Biochemistry", institution: "UCLA", year: "2005" },
    ],
    selectedPublications: [
      {
        title: "Experimental validation of kill-switch evolution predictions",
        journal: "ACS Synthetic Biology",
        year: "2024",
      },
      {
        title: "Engineering robust biocontainment in E. coli chassis strains",
        journal: "Nature Biotechnology",
        year: "2023",
      },
    ],
    researchInterests: [
      "Synthetic biosafety systems",
      "Genetic circuit engineering",
      "Experimental evolution",
      "Biocontainment validation",
    ],
    website: "https://example.com/david-chen",
    twitter: "davidchen_synbio",
    linkedin: "david-chen-berkeley",
  },
}

export default async function MemberPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const member = membersData[id as keyof typeof membersData]

  if (!member) {
    notFound()
  }

  return (
    <div className="min-h-screen">
      {/* Back Button */}
      <div className="mx-auto max-w-7xl px-6 pt-6 lg:px-8">
        <Button asChild variant="ghost" size="sm" className="text-gray-300 hover:text-white hover:bg-white/10">
          <Link href="/members">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Team
          </Link>
        </Button>
      </div>

      {/* Profile Header */}
      <section className="py-10">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
              <div className="lg:col-span-1">
                <div className="aspect-square overflow-hidden rounded-lg shadow-2xl">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>
              <div className="lg:col-span-2">
                <Badge className="mb-4 bg-amber-500/20 text-amber-300 border-amber-500/30 font-light tracking-wider text-xs">{member.role}</Badge>
                <h1 className="font-serif text-4xl font-light tracking-wide text-white sm:text-5xl">{member.name}</h1>
                <p className="mt-3 text-xl text-gray-400 font-light">
                  {member.position} &middot; {member.department}
                </p>
                <p className="text-lg text-gray-500 font-light">{member.institution}</p>

                <div className="mt-6 flex flex-wrap gap-2">
                  {member.expertise.map((exp) => (
                    <Badge key={exp} variant="outline" className="border-white/20 text-gray-300 font-light">
                      {exp}
                    </Badge>
                  ))}
                </div>

                <div className="mt-8 flex flex-wrap gap-3">
                  <Button size="lg" asChild className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
                    <a href={`mailto:${member.email}`}>
                      <Mail className="mr-2 h-4 w-4" />
                      Contact
                    </a>
                  </Button>
                  {member.website && (
                    <Button
                      size="lg"
                      variant="outline"
                      asChild
                      className="border-white/20 text-white hover:bg-white/10 bg-transparent font-light tracking-wide"
                    >
                      <a href={member.website} target="_blank" rel="noopener noreferrer">
                        <Globe className="mr-2 h-4 w-4" />
                        Website
                      </a>
                    </Button>
                  )}
                  {member.linkedin && (
                    <Button
                      size="lg"
                      variant="outline"
                      asChild
                      className="border-white/20 text-white hover:bg-white/10 bg-transparent font-light tracking-wide"
                    >
                      <a href={`https://linkedin.com/in/${member.linkedin}`} target="_blank" rel="noopener noreferrer">
                        <Linkedin className="mr-2 h-4 w-4" />
                        LinkedIn
                      </a>
                    </Button>
                  )}
                  {member.twitter && (
                    <Button
                      size="lg"
                      variant="outline"
                      asChild
                      className="border-white/20 text-white hover:bg-white/10 bg-transparent font-light tracking-wide"
                    >
                      <a href={`https://twitter.com/${member.twitter}`} target="_blank" rel="noopener noreferrer">
                        <Twitter className="mr-2 h-4 w-4" />
                        Twitter
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Profile Content */}
      <section className="py-8">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Biography */}
              <Card className="glass-dark border-white/10">
                <CardContent className="p-8">
                  <h2 className="flex items-center font-serif text-2xl font-light tracking-wide text-amber-100">
                    <Users className="mr-3 h-6 w-6 text-amber-400" />
                    Biography
                  </h2>
                  <Separator className="my-4 bg-white/10" />
                  <p className="pl-1 text-gray-400 leading-relaxed">{member.bio}</p>
                </CardContent>
              </Card>

              {/* Research Interests */}
              <Card className="glass-dark border-white/10">
                <CardContent className="p-8">
                  <h2 className="flex items-center font-serif text-2xl font-light tracking-wide text-amber-100">
                    <BookOpen className="mr-3 h-6 w-6 text-amber-400" />
                    Research Interests
                  </h2>
                  <Separator className="my-4 bg-white/10" />
                  <ul className="pl-1 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {member.researchInterests.map((interest) => (
                      <li key={interest} className="flex items-start">
                        <span className="mr-2 mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-amber-500" />
                        <span className="text-gray-400">{interest}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Selected Publications */}
              <Card className="glass-dark border-white/10">
                <CardContent className="p-8">
                  <h2 className="flex items-center font-serif text-2xl font-light tracking-wide text-amber-100">
                    <Award className="mr-3 h-6 w-6 text-amber-400" />
                    Selected Publications
                  </h2>
                  <Separator className="my-4 bg-white/10" />
                  <ul className="pl-1 space-y-4">
                    {member.selectedPublications.map((pub, idx) => (
                      <li key={idx} className="border-l-2 border-amber-500/40 pl-4">
                        <p className="font-light text-gray-200">{pub.title}</p>
                        <p className="text-sm text-gray-500">
                          {pub.journal} ({pub.year})
                        </p>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Education */}
              <Card className="glass-dark border-white/10">
                <CardContent className="p-6">
                  <h3 className="font-serif text-xl font-light tracking-wide text-amber-100">Education</h3>
                  <Separator className="my-4 bg-white/10" />
                  <ul className="space-y-4">
                    {member.education.map((edu, idx) => (
                      <li key={idx}>
                        <p className="font-light text-gray-200 text-sm">{edu.degree}</p>
                        <p className="text-xs text-gray-400">{edu.institution}</p>
                        <p className="text-xs text-gray-500">{edu.year}</p>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Contact Card */}
              <Card className="glass-dark border-white/10">
                <CardContent className="p-6">
                  <h3 className="font-serif text-xl font-light tracking-wide text-amber-100">Get in Touch</h3>
                  <Separator className="my-4 bg-white/10" />
                  <p className="text-sm text-gray-400 leading-relaxed mb-4">
                    Interested in collaboration or have questions about our research?
                  </p>
                  <Button asChild className="w-full bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
                    <a href={`mailto:${member.email}`}>
                      <Mail className="mr-2 h-4 w-4" />
                      Send Email
                    </a>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
