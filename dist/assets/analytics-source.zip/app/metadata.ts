import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Evolutionary Risk Analytics | Predictive Evolution & Synthetic Biology Containment",
  description:
    "Leading research in biosecurity, containment frameworks, kill-switch evolution, and risk assessment for synthetic biology. Rigorous mathematical frameworks for evolutionary risk.",
  keywords:
    "biosecurity, synthetic biology, containment, evolutionary genetics, kill switches, mathematics, risk assessment, evolutionary risk analytics",
}
