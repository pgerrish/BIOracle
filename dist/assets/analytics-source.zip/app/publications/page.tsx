import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { BookOpen, ExternalLink, Search, FileText } from "lucide-react"

const publications = [
  {
    year: "2024",
    items: [
      {
        title: "Predictive frameworks for biocontainment expiration in engineered systems",
        authors: "Rodriguez M, Garcia J, Chen D",
        journal: "Nature Biotechnology",
        volume: "42(3)",
        pages: "412-428",
        doi: "10.1038/nbt.2024.123",
        type: "Article",
      },
      {
        title: "Evolutionary pathways to kill-switch failure in synthetic bacteria",
        authors: "Garcia J, Rodriguez M, Lopez A",
        journal: "Science Advances",
        volume: "10(8)",
        pages: "eabc1234",
        doi: "10.1126/sciadv.abc1234",
        type: "Article",
      },
      {
        title: "Experimental validation of kill-switch evolution predictions",
        authors: "Chen D, Garcia J, Rodriguez M",
        journal: "ACS Synthetic Biology",
        volume: "13(5)",
        pages: "1245-1258",
        doi: "10.1021/acssynbio.2024.00123",
        type: "Article",
      },
      {
        title: "Game-theoretic models of evolutionary escape in synthetic systems",
        authors: "Hernandez S, Rodriguez M",
        journal: "Journal of Theoretical Biology",
        volume: "572",
        pages: "111589",
        doi: "10.1016/j.jtbi.2024.111589",
        type: "Article",
      },
    ],
  },
  {
    year: "2023",
    items: [
      {
        title: "Mathematical analysis of kill-switch evolutionary stability",
        authors: "Rodriguez M, Garcia J",
        journal: "PLOS Computational Biology",
        volume: "19(11)",
        pages: "e1011234",
        doi: "10.1371/journal.pcbi.1011234",
        type: "Article",
      },
      {
        title: "Population dynamics of engineered microorganisms under selection",
        authors: "Garcia J, Rodriguez M",
        journal: "Nature Communications",
        volume: "14",
        pages: "5678",
        doi: "10.1038/s41467-023-05678-x",
        type: "Article",
      },
      {
        title: "Network-based assessment of engineered organism spillover potential",
        authors: "Lopez A, Rodriguez M",
        journal: "Ecology Letters",
        volume: "26(4)",
        pages: "612-628",
        doi: "10.1111/ele.14234",
        type: "Article",
      },
      {
        title: "Engineering robust biocontainment in E. coli chassis strains",
        authors: "Chen D, Garcia J",
        journal: "Nature Biotechnology",
        volume: "41(9)",
        pages: "1234-1245",
        doi: "10.1038/nbt.2023.456",
        type: "Article",
      },
    ],
  },
  {
    year: "2022",
    items: [
      {
        title: "Stochastic models for synthetic gene circuit degradation",
        authors: "Rodriguez M, Garcia J, Lopez A",
        journal: "Molecular Systems Biology",
        volume: "18(6)",
        pages: "e10876",
        doi: "10.15252/msb.202210876",
        type: "Article",
      },
      {
        title: "Ecological risk factors in synthetic biology release",
        authors: "Lopez A, Rodriguez M",
        journal: "Trends in Ecology & Evolution",
        volume: "37(8)",
        pages: "712-724",
        doi: "10.1016/j.tree.2022.05.008",
        type: "Review",
      },
      {
        title: "Biosecurity considerations in the age of AI-designed proteins",
        authors: "Rodriguez M, Chen D, Garcia J",
        journal: "Annual Review of Biomedical Engineering",
        volume: "24",
        pages: "389-415",
        doi: "10.1146/annurev-bioeng-092022-123456",
        type: "Review",
      },
    ],
  },
]

export default function PublicationsPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <BookOpen className="h-10 w-10 text-amber-400 mb-6" />
            <h1 className="font-serif text-5xl font-light tracking-wide text-white sm:text-6xl">Publications</h1>
            <p className="mt-4 pl-1 text-lg text-gray-400 max-w-2xl text-pretty">
              Peer-reviewed research from our evolutionary risk analytics group
            </p>
          </div>
        </div>
      </section>

      {/* Search Bar */}
      <section className="pb-8">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-6 py-5">
            <div className="relative max-w-2xl">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
              <Input
                type="search"
                placeholder="Search publications by title, author, or keyword..."
                className="pl-10 h-12 border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Publications by Year */}
      <section className="py-8">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="space-y-14">
              {publications.map((yearGroup) => (
                <div key={yearGroup.year}>
                  <div className="mb-6 flex items-center">
                    <h2 className="font-serif text-4xl font-light tracking-wide text-amber-200">{yearGroup.year}</h2>
                    <div className="ml-6 flex-1 h-px bg-white/10" />
                    <Badge variant="secondary" className="ml-4 bg-white/10 text-gray-400 border-white/10 font-light">
                      {yearGroup.items.length} publications
                    </Badge>
                  </div>

                  <div className="space-y-4 pl-1">
                    {yearGroup.items.map((pub, idx) => (
                      <div
                        key={idx}
                        className="group rounded-lg border border-white/10 bg-white/5 p-6 hover:bg-white/10 transition-all"
                      >
                        <div className="flex items-start gap-4">
                          <div className="flex-shrink-0">
                            <div className="inline-flex h-10 w-10 items-center justify-center rounded-md bg-amber-500/20">
                              <FileText className="h-5 w-5 text-amber-400" />
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1">
                                <Badge variant="outline" className="mb-2 border-white/15 text-gray-500 font-light text-xs">
                                  {pub.type}
                                </Badge>
                                <h3 className="font-serif text-lg font-normal text-amber-100 leading-snug">{pub.title}</h3>
                                <p className="mt-2 text-sm text-gray-400">{pub.authors}</p>
                                <p className="mt-1 text-sm text-gray-500">
                                  <span className="font-medium text-gray-400">{pub.journal}</span> {pub.volume}, {pub.pages}
                                </p>
                              </div>
                              <Button size="sm" variant="outline" asChild className="flex-shrink-0 bg-transparent border-white/15 text-gray-400 hover:bg-white/10 hover:text-white">
                                <a href={`https://doi.org/${pub.doi}`} target="_blank" rel="noopener noreferrer">
                                  View <ExternalLink className="ml-1 h-3 w-3" />
                                </a>
                              </Button>
                            </div>
                            <div className="mt-3 text-xs text-gray-600">
                              <span>DOI: {pub.doi}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
              {[
                { value: "60+", label: "Total Publications" },
                { value: "2,500+", label: "Total Citations" },
                { value: "15+", label: "Journals" },
              ].map(({ value, label }) => (
                <div key={label} className="text-left pl-4 border-l border-amber-500/40">
                  <p className="font-serif text-5xl font-light text-amber-400">{value}</p>
                  <p className="mt-2 text-gray-400 text-sm tracking-wider uppercase">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
