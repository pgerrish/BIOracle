import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Shield,
  Dna,
  TrendingUp,
  AlertTriangle,
  Target,
  Microscope,
  BookOpen,
  ExternalLink,
  ChevronRight,
} from "lucide-react"

const researchAreas = [
  {
    title: "Containment Expiration Frameworks",
    icon: Shield,
    description:
      "Developing predictive mathematical models to determine when biocontainment systems will fail and establishing evidence-based expiration dates for containment strategies.",
    challenges: [
      "Quantifying mutation accumulation over time",
      "Modeling selection pressures in contained environments",
      "Integrating stochastic escape events",
      "Accounting for horizontal gene transfer",
    ],
    approaches: [
      "Stochastic differential equations",
      "Monte Carlo simulations",
      "Bayesian inference frameworks",
      "Time-series reliability analysis",
    ],
    applications: [
      "Industrial bioreactor safety protocols",
      "Environmental release risk windows",
      "Regulatory compliance timelines",
      "Laboratory containment scheduling",
    ],
  },
  {
    title: "Bacterial Kill-Switch Evolution",
    icon: Dna,
    description:
      "Investigating the evolutionary stability of genetic kill-switches and predicting pathways to escape from toxin-antitoxin systems and inducible suicide mechanisms.",
    challenges: [
      "Predicting compensatory mutations",
      "Understanding fitness trade-offs",
      "Modeling gene circuit degradation",
      "Assessing cross-feeding dynamics",
    ],
    approaches: [
      "Population genetics theory",
      "Evolutionary game theory",
      "Mutation-selection balance models",
      "Experimental evolution validation",
    ],
    applications: [
      "Robust kill-switch design principles",
      "Multi-layered safety system optimization",
      "Auxotrophy strategy evaluation",
      "Genetic firewall development",
    ],
  },
  {
    title: "Spillover Risk Assessment",
    icon: TrendingUp,
    description:
      "Quantifying the probability and impact of engineered organisms establishing in natural ecosystems or interacting with immune systems in unintended ways.",
    challenges: [
      "Modeling ecological fitness landscapes",
      "Predicting host-range expansion",
      "Assessing immunogenicity risks",
      "Understanding community-level impacts",
    ],
    approaches: [
      "Ecological network analysis",
      "Trait-based modeling",
      "Phylogenetic risk prediction",
      "Agent-based ecosystem simulations",
    ],
    applications: [
      "Environmental release safety protocols",
      "Agricultural biosafety standards",
      "Therapeutic organism design guidelines",
      "Ecosystem impact assessments",
    ],
  },
  {
    title: "Interaction Risks",
    icon: AlertTriangle,
    description:
      "Analyzing potential adverse interactions between engineered systems and host immune responses, microbiomes, or ecological communities.",
    challenges: [
      "Characterizing immune response dynamics",
      "Modeling microbiome perturbations",
      "Predicting off-target ecological effects",
      "Assessing cascade failures",
    ],
    approaches: [
      "Systems biology modeling",
      "Network perturbation analysis",
      "Immunological modeling",
      "Food web dynamics",
    ],
    applications: [
      "Live biotherapeutic safety evaluation",
      "Agricultural biocontrol risk assessment",
      "Probiotic strain safety testing",
      "Ecosystem restoration planning",
    ],
  },
  {
    title: "Evolutionary Targets of Concern",
    icon: Target,
    description:
      "Identifying specific evolutionary trajectories, mutations, or gene combinations that would create heightened biosecurity risks and developing early warning systems.",
    challenges: [
      "Defining risk-relevant phenotypes",
      "Predicting convergent evolution",
      "Monitoring population-level changes",
      "Establishing intervention thresholds",
    ],
    approaches: [
      "Predictive evolutionary modeling",
      "Sequence-to-phenotype mapping",
      "Risk-weighted trajectory analysis",
      "Real-time genomic surveillance integration",
    ],
    applications: [
      "Early warning surveillance systems",
      "Intervention trigger protocols",
      "Adaptive management frameworks",
      "Regulatory monitoring programs",
    ],
  },
]

const syntheticBiologyContext = {
  overview:
    "Synthetic biology enables the design and construction of new biological parts, devices, and systems for useful purposes. However, these capabilities raise important biosecurity considerations that require rigorous mathematical and theoretical frameworks.",
  keyConcepts: [
    {
      term: "Biocontainment",
      definition:
        "Strategies to prevent engineered organisms from persisting in unintended environments, including genetic, chemical, and physical barriers.",
    },
    {
      term: "Kill Switches",
      definition:
        "Genetic circuits designed to eliminate cells when specific conditions are met or when they escape containment, using toxin-antitoxin systems or essential gene dependencies.",
    },
    {
      term: "Evolutionary Stability",
      definition:
        "The capacity of engineered genetic circuits to resist degradation or escape through mutation and selection over microbial generations.",
    },
    {
      term: "Auxotrophy",
      definition:
        "Engineering organisms to require specific nutrients not available in natural environments, creating a metabolic dependency for survival.",
    },
    {
      term: "Gene Drive",
      definition:
        "Genetic elements that bias inheritance to increase their frequency in populations, with potential for rapid ecological spread.",
    },
  ],
  currentChallenges: [
    "Traditional homology-based DNA screening is inadequate for generative AI-designed proteins with novel functions",
    "Synthetic gene circuits often degrade over time due to mutation and selection pressures from host resource burden",
    "Horizontal gene transfer can spread engineered genetic elements to non-target organisms",
    "Long-term evolutionary dynamics of engineered systems remain poorly characterized",
    "Risk assessment frameworks lag behind the pace of technological advancement",
  ],
}

export default function ResearchPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <Badge className="mb-6 bg-amber-500/20 text-amber-300 border-amber-500/30 font-light tracking-wider uppercase text-xs">
              Research Focus
            </Badge>
            <h1 className="font-serif text-5xl font-light tracking-wide text-white sm:text-6xl max-w-3xl">
              Mathematical Biosecurity Research
            </h1>
            <p className="mt-6 pl-1 text-lg text-gray-400 max-w-2xl text-pretty">
              Advancing predictive frameworks for containment, evolutionary modeling, and risk assessment in synthetic
              biology systems
            </p>
          </div>
        </div>
      </section>

      {/* Synthetic Biology Context */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
              <div>
                <div className="flex items-center mb-6">
                  <Microscope className="h-7 w-7 text-amber-400 mr-3" />
                  <h2 className="font-serif text-3xl font-light tracking-wide text-amber-100">Synthetic Biology Context</h2>
                </div>
                <p className="pl-1 text-gray-400 leading-relaxed mb-8">{syntheticBiologyContext.overview}</p>
                <div className="pl-1 space-y-4">
                  <h3 className="text-xs font-medium uppercase tracking-widest text-gray-500">Current Challenges</h3>
                  {syntheticBiologyContext.currentChallenges.map((challenge, idx) => (
                    <div key={idx} className="flex items-start">
                      <AlertTriangle className="h-4 w-4 text-amber-500 mr-3 flex-shrink-0 mt-1" />
                      <p className="text-sm text-gray-400 leading-relaxed">{challenge}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-serif text-2xl font-light tracking-wide text-amber-100 mb-6">Key Concepts</h3>
                <div className="space-y-4">
                  {syntheticBiologyContext.keyConcepts.map((concept, idx) => (
                    <div key={idx} className="rounded-lg border border-white/10 bg-white/5 p-5">
                      <h4 className="font-serif text-lg font-normal text-amber-200">{concept.term}</h4>
                      <p className="mt-1 text-sm text-gray-400 leading-relaxed">{concept.definition}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Research Areas */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="max-w-2xl mb-12">
              <h2 className="font-serif text-4xl font-light tracking-wide text-amber-100 sm:text-5xl">Research Areas</h2>
              <p className="mt-4 pl-1 text-lg text-gray-400 text-pretty">
                Our work spans five interconnected domains of biosecurity research
              </p>
            </div>

            <div className="space-y-8">
              {researchAreas.map((area, idx) => {
                const Icon = area.icon
                return (
                  <Card key={idx} className="overflow-hidden hover:shadow-md transition-shadow border-white/10 bg-white/5">
                    <CardHeader className="border-b border-white/10 bg-white/5">
                      <div className="flex items-start gap-4">
                        <div className="inline-flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-md bg-amber-500/20">
                          <Icon className="h-6 w-6 text-amber-400" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="font-serif text-2xl font-light tracking-wide text-amber-100">{area.title}</CardTitle>
                          <CardDescription className="mt-2 text-base text-gray-400">{area.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                        {[
                          { label: "Challenges", items: area.challenges, color: "text-gray-500" },
                          { label: "Approaches", items: area.approaches, color: "text-amber-500" },
                          { label: "Applications", items: area.applications, color: "text-gray-500" },
                        ].map(({ label, items, color }) => (
                          <div key={label}>
                            <h4 className="mb-3 text-xs font-medium uppercase tracking-widest text-gray-500">
                              {label}
                            </h4>
                            <ul className="space-y-2">
                              {items.map((item, iidx) => (
                                <li key={iidx} className="flex items-start text-sm text-gray-400">
                                  <ChevronRight className={`mr-1 h-4 w-4 flex-shrink-0 ${color} mt-0.5`} />
                                  {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Methodology Section */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="max-w-2xl mb-12">
              <h2 className="font-serif text-4xl font-light tracking-wide text-amber-100 sm:text-5xl">Our Approach</h2>
              <p className="mt-4 pl-1 text-lg text-gray-400 text-pretty">
                Combining theoretical rigor with practical applications
              </p>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
              {[
                { icon: BookOpen, title: "Theoretical Foundation", text: "Grounded in evolutionary genetics, mathematical modeling, and stochastic processes with rigorous peer-reviewed validation.", accent: "bg-amber-500/20 text-amber-400" },
                { icon: Target, title: "Predictive Frameworks", text: "Developing quantitative tools to forecast evolutionary outcomes and assess risks before they materialize in real systems.", accent: "bg-white/10 text-gray-300" },
                { icon: Microscope, title: "Experimental Validation", text: "Collaborating with experimental synthetic biologists to test theoretical predictions and refine models with empirical data.", accent: "bg-amber-500/15 text-amber-300" },
              ].map(({ icon: Icon, title, text, accent }) => (
                <div key={title} className="rounded-lg border border-white/10 bg-white/5 p-8">
                  <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md ${accent}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="font-serif text-xl font-normal text-amber-100">{title}</h3>
                  <p className="mt-3 text-sm text-gray-400 leading-relaxed">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <div className="max-w-2xl">
              <h2 className="font-serif text-4xl font-light tracking-wide text-white sm:text-5xl text-balance">
                Collaborate on Biosecurity Research
              </h2>
              <p className="mt-4 pl-1 text-lg text-gray-400 text-pretty">
                Interested in partnerships, joint projects, or applying our frameworks to your work?
              </p>
              <div className="mt-10 pl-1 flex flex-wrap items-center gap-4">
                <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-medium tracking-wide">
                  <Link href="/contact">Start a Conversation</Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10 bg-transparent font-light tracking-wide"
                >
                  <Link href="/publications">
                    View Publications <ExternalLink className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
