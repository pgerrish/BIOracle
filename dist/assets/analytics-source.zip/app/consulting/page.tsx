"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle2, Calendar, CreditCard, FileText, Users, Zap, Shield, TrendingUp } from "lucide-react"

const services = [
  {
    title: "Biosecurity Risk Assessment",
    description:
      "Comprehensive evaluation of containment strategies and evolutionary risks for synthetic biology projects",
    icon: Shield,
    features: [
      "Kill-switch robustness analysis",
      "Containment expiration prediction",
      "Spillover risk quantification",
      "Regulatory compliance guidance",
    ],
    duration: "2-4 weeks",
    price: "Contact for pricing",
  },
  {
    title: "Evolutionary Modeling",
    description: "Custom mathematical frameworks to predict evolutionary trajectories in engineered systems",
    icon: TrendingUp,
    features: [
      "Stochastic evolutionary models",
      "Population dynamics simulation",
      "Mutation-selection analysis",
      "Long-term stability forecasting",
    ],
    duration: "4-8 weeks",
    price: "Contact for pricing",
  },
  {
    title: "Strategic Consulting",
    description: "Expert guidance on biosecurity strategy, research direction, and regulatory navigation",
    icon: Users,
    features: [
      "One-on-one expert sessions",
      "Research strategy development",
      "Funding proposal review",
      "Regulatory pathway planning",
    ],
    duration: "Hourly or project-based",
    price: "$300/hour",
  },
  {
    title: "Rapid Assessment",
    description: "Quick turnaround analysis for time-sensitive biosecurity questions",
    icon: Zap,
    features: [
      "48-hour preliminary assessment",
      "Executive summary report",
      "Critical risk identification",
      "Recommended action items",
    ],
    duration: "2-3 days",
    price: "Starting at $2,500",
  },
]

const process = [
  {
    step: "1",
    title: "Initial Consultation",
    description: "Discuss your needs, project scope, and objectives in a free 30-minute call",
  },
  {
    step: "2",
    title: "Proposal & Agreement",
    description: "Receive a detailed proposal with timeline, deliverables, and pricing",
  },
  {
    step: "3",
    title: "Project Execution",
    description: "Our team conducts analysis with regular progress updates and communication",
  },
  {
    step: "4",
    title: "Delivery & Support",
    description: "Receive comprehensive report with findings and ongoing support as needed",
  },
]

export default function ConsultingPage() {
  const [requestForm, setRequestForm] = useState({
    name: "",
    email: "",
    organization: "",
    service: "",
    timeline: "",
    details: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Consultation request:", requestForm)
    alert("Thank you! We'll review your request and get back to you within 24 hours.")
    setRequestForm({ name: "", email: "", organization: "", service: "", timeline: "", details: "" })
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-16 sm:px-12">
            <h1 className="font-serif text-5xl font-light tracking-wide text-white sm:text-6xl max-w-3xl">
              Consulting Services
            </h1>
            <p className="mt-6 pl-1 text-lg text-gray-400 max-w-2xl text-pretty">
              Expert biosecurity and evolutionary modeling services for industry, government, and academic partners
            </p>
            <div className="mt-10 pl-1 flex flex-wrap items-center gap-4">
              <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
                <a href="#request">Request Consultation</a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 bg-transparent font-light tracking-wide"
              >
                <a href="#services">View Services</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-8">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="max-w-2xl mb-12">
              <h2 className="font-serif text-4xl font-light tracking-wide text-amber-100 sm:text-5xl">Our Services</h2>
              <p className="mt-4 pl-1 text-lg text-gray-400 text-pretty">
                Comprehensive biosecurity expertise tailored to your needs
              </p>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
              {services.map((service, idx) => {
                const Icon = service.icon
                return (
                  <Card key={idx} className="border-white/10 bg-white/5 hover:bg-white/10 transition-all">
                    <CardHeader>
                      <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-amber-500/20">
                        <Icon className="h-6 w-6 text-amber-400" />
                      </div>
                      <CardTitle className="font-serif text-2xl font-light tracking-wide text-amber-100">{service.title}</CardTitle>
                      <CardDescription className="text-gray-400">{service.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-4 space-y-2">
                        {service.features.map((feature, fidx) => (
                          <div key={fidx} className="flex items-start">
                            <CheckCircle2 className="mr-2 h-4 w-4 text-amber-500 flex-shrink-0 mt-0.5" />
                            <span className="text-sm text-gray-400">{feature}</span>
                          </div>
                        ))}
                      </div>
                      <Separator className="my-4 bg-white/10" />
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center text-gray-400">
                          <Calendar className="mr-1 h-4 w-4" />
                          {service.duration}
                        </div>
                        <Badge variant="secondary" className="bg-amber-500/20 text-amber-300 border-amber-500/20 font-light">{service.price}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="max-w-2xl mb-12">
              <h2 className="font-serif text-4xl font-light tracking-wide text-amber-100 sm:text-5xl">How It Works</h2>
              <p className="mt-4 pl-1 text-lg text-gray-400 text-pretty">A streamlined process from inquiry to delivery</p>
            </div>

            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
              {process.map((item, idx) => (
                <div key={idx} className="relative">
                  <div className="flex flex-col items-start pl-4 border-l-2 border-amber-500/40">
                    <span className="font-serif text-4xl font-light text-amber-400">{item.step}</span>
                    <h3 className="mt-2 font-serif text-lg font-normal text-amber-100">{item.title}</h3>
                    <p className="mt-2 text-sm text-gray-400 text-pretty">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Request Form Section */}
      <section id="request" className="py-8">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-3xl">
            <Card className="glass-dark border-white/10">
              <CardHeader>
                <CardTitle className="font-serif text-2xl font-light tracking-wide text-amber-100">Request a Consultation</CardTitle>
                <CardDescription className="text-gray-400">
                  Fill out the form below and we{"'"}ll get back to you within 24 hours to discuss your needs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="req-name" className="font-light tracking-wide text-gray-300">Full Name *</Label>
                      <Input
                        id="req-name"
                        required
                        value={requestForm.name}
                        onChange={(e) => setRequestForm({ ...requestForm, name: e.target.value })}
                        className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="req-email" className="font-light tracking-wide text-gray-300">Email *</Label>
                      <Input
                        id="req-email"
                        type="email"
                        required
                        value={requestForm.email}
                        onChange={(e) => setRequestForm({ ...requestForm, email: e.target.value })}
                        className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="req-org" className="font-light tracking-wide text-gray-300">Organization *</Label>
                    <Input
                      id="req-org"
                      required
                      value={requestForm.organization}
                      onChange={(e) => setRequestForm({ ...requestForm, organization: e.target.value })}
                      placeholder="Company, University, or Government Agency"
                      className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="req-service" className="font-light tracking-wide text-gray-300">Service Needed *</Label>
                      <Select
                        required
                        value={requestForm.service}
                        onValueChange={(value) => setRequestForm({ ...requestForm, service: value })}
                      >
                        <SelectTrigger className="border-white/10 bg-white/5 text-gray-200">
                          <SelectValue placeholder="Select a service" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="risk-assessment">Biosecurity Risk Assessment</SelectItem>
                          <SelectItem value="modeling">Evolutionary Modeling</SelectItem>
                          <SelectItem value="strategic">Strategic Consulting</SelectItem>
                          <SelectItem value="rapid">Rapid Assessment</SelectItem>
                          <SelectItem value="custom">Custom Project</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="req-timeline" className="font-light tracking-wide text-gray-300">Desired Timeline *</Label>
                      <Select
                        required
                        value={requestForm.timeline}
                        onValueChange={(value) => setRequestForm({ ...requestForm, timeline: value })}
                      >
                        <SelectTrigger className="border-white/10 bg-white/5 text-gray-200">
                          <SelectValue placeholder="Select timeline" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="urgent">Urgent (1-2 weeks)</SelectItem>
                          <SelectItem value="standard">Standard (1-2 months)</SelectItem>
                          <SelectItem value="flexible">Flexible (2+ months)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="req-details" className="font-light tracking-wide text-gray-300">Project Details *</Label>
                    <Textarea
                      id="req-details"
                      required
                      value={requestForm.details}
                      onChange={(e) => setRequestForm({ ...requestForm, details: e.target.value })}
                      placeholder="Describe your project, goals, and any specific requirements..."
                      rows={6}
                      className="border-white/10 bg-white/5 text-gray-200 placeholder:text-gray-500"
                    />
                  </div>

                  <Button type="submit" size="lg" className="w-full bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
                    Submit Request
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Payment & Agreements Section */}
      <section id="schedule" className="py-16">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="glass-dark rounded-lg px-8 py-14 sm:px-12">
            <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
              <div className="rounded-lg border border-white/10 bg-white/5 p-8">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-amber-500/10">
                  <CreditCard className="h-6 w-6 text-amber-400" />
                </div>
                <h3 className="font-serif text-2xl font-light tracking-wide text-white">Payment Options</h3>
                <p className="mt-2 text-sm text-gray-400">Flexible payment terms for all clients</p>
                <div className="mt-6 space-y-3 text-sm text-gray-300">
                  {[
                    "Bank transfer (preferred for international clients)",
                    "Credit card and online payment",
                    "Milestone-based payment schedules available",
                    "Invoice and purchase order accepted",
                  ].map((item, i) => (
                    <p key={i} className="flex items-start">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-amber-400 flex-shrink-0 mt-0.5" />
                      {item}
                    </p>
                  ))}
                </div>
              </div>

              <div className="rounded-lg border border-white/10 bg-white/5 p-8">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-amber-500/10">
                  <FileText className="h-6 w-6 text-amber-400" />
                </div>
                <h3 className="font-serif text-2xl font-light tracking-wide text-white">Agreements & Confidentiality</h3>
                <p className="mt-2 text-sm text-gray-400">Your intellectual property is protected</p>
                <div className="mt-6 space-y-3 text-sm text-gray-300">
                  {[
                    "Non-disclosure agreements (NDAs) standard",
                    "Clear intellectual property terms",
                    "Formal service agreements provided",
                    "Customizable terms for long-term partnerships",
                  ].map((item, i) => (
                    <p key={i} className="flex items-start">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-amber-400 flex-shrink-0 mt-0.5" />
                      {item}
                    </p>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-14 max-w-xl">
              <h3 className="font-serif text-3xl font-light tracking-wide text-white">Ready to Get Started?</h3>
              <p className="mt-2 pl-1 text-gray-400">Contact us today to discuss your biosecurity needs</p>
              <div className="mt-8 pl-1">
                <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-gray-950 font-light tracking-wide">
                  <Link href="/contact">Contact Us</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
